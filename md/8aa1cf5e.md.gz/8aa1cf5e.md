Source: contracts\DEPLOYMENT_GUIDE.md

```md
# NFT Smart Contract Deployment Guide

## Prerequisites
1. MetaMask wallet installed
2. Sepolia testnet ETH (get from [Sepolia Faucet](https://sepoliafaucet.com/))
3. [Remix IDE](https://remix.ethereum.org/) or Hardhat

## Option 1: Deploy with Remix (Easiest)

### Step 1: Open Remix
1. Go to https://remix.ethereum.org/
2. Create a new file: `GameCharacterNFT.sol`
3. Copy the contract code from `contracts/GameCharacterNFT.sol`

### Step 2: Install OpenZeppelin (REQUIRED)
1. In Remix, go to the "File Explorer" tab
2. Right-click on "contracts" folder
3. Use the Remix plugin: "OpenZeppelin Contracts"
4. The contract uses **ERC721Enumerable** extension for NFT enumeration

**Important:** The contract inherits from `ERC721Enumerable`, which provides the `tokenOfOwnerByIndex` function needed for the game to read your NFTs.

### Step 3: Compile
1. Click "Solidity Compiler" tab (left sidebar)
2. Select compiler version: `0.8.20+`
3. Click "Compile GameCharacterNFT.sol"

### Step 4: Deploy to Testnet
1. Click "Deploy & Run Transactions" tab
2. Environment: Select "Injected Provider - MetaMask"
3. Connect your MetaMask (ensure you're on Sepolia testnet)
4. Click "Deploy"
5. Confirm transaction in MetaMask
6. **SAVE YOUR CONTRACT ADDRESS!**

### Step 5: Mint Test NFTs
After deployment, use these functions:

```javascript
// Mint a single character
mintCharacter(
  "0xYourWalletAddress",
  75,  // strength (1-100)
  82,  // dexterity (1-100)
  68,  // constitution (1-100)
  90,  // intelligence (1-100)
  4,   // rarity (1-5, where 5 is legendary)
  "Sniper Elite",  // special ability
  "ipfs://QmYourMetadataHash"  // metadata URI
)
```

## Option 2: Deploy with Hardhat

### Installation
```bash
npm install --save-dev hardhat @openzeppelin/contracts
npx hardhat init
```

### hardhat.config.js
```javascript
require("@nomicfoundation/hardhat-toolbox");
require('dotenv').config();

module.exports = {
  solidity: "0.8.20",
  networks: {
    sepolia: {
      url: process.env.SEPOLIA_RPC_URL,
      accounts: [process.env.PRIVATE_KEY]
    }
  }
};
```

### Deploy Script (`scripts/deploy.js`)
```javascript
async function main() {
  const GameCharacterNFT = await ethers.getContractFactory("GameCharacterNFT");
  const nft = await GameCharacterNFT.deploy();
  await nft.deployed();
  
  console.log("GameCharacterNFT deployed to:", nft.address);
  
  // Mint a test NFT
  const tx = await nft.mintCharacter(
    "0xYourWalletAddress",
    75, 82, 68, 90, 4,
    "Sniper Elite",
    "ipfs://QmYourMetadataHash"
  );
  await tx.wait();
  console.log("Test NFT minted!");
}

main();
```

### Deploy
```bash
npx hardhat run scripts/deploy.js --network sepolia
```

## Updating Your Game

After deployment, update `src/pages/PhysicsDemo.jsx`:

```javascript
// Add near the top of the component
const NFT_CONTRACT_ADDRESS = "0xYourContractAddressHere"; // Paste from deployment
const NFT_CONTRACT_NETWORK = "sepolia"; // or "mainnet" later
```

## Minting NFTs for Testing

Create characters with different stats and rarities:

### Common Character (Rarity 1)
```solidity
mintCharacter(yourAddress, 45, 50, 48, 42, 1, "None", "ipfs://...")
```

### Rare Character (Rarity 3)
```solidity
mintCharacter(yourAddress, 70, 75, 68, 72, 3, "Double Shot", "ipfs://...")
```

### Legendary Character (Rarity 5)
```solidity
mintCharacter(yourAddress, 95, 92, 88, 96, 5, "God Mode", "ipfs://...")
```

## Creating Metadata (IPFS)

### Metadata JSON Format
```json
{
  "name": "Cyber Warrior #1",
  "description": "A legendary cyber warrior from the future",
  "image": "ipfs://QmImageHash",
  "attributes": [
    {"trait_type": "Class", "value": "Warrior"},
    {"trait_type": "Element", "value": "Cyber"},
    {"trait_type": "Generation", "value": "Genesis"}
  ]
}
```

### Upload to IPFS
1. Use [Pinata](https://pinata.cloud/) (free tier available)
2. Or [NFT.Storage](https://nft.storage/) (free)
3. Upload your metadata JSON
4. Use the returned IPFS hash in `mintCharacter()`

## Batch Minting
To mint multiple NFTs at once:

```solidity
batchMintCharacters(
  [address1, address2, address3],  // recipients
  [75, 82, 65],                    // strengths
  [80, 88, 70],                    // dexterities
  [70, 75, 80],                    // constitutions
  [85, 90, 60],                    // intelligences
  [3, 4, 2],                       // rarities
  ["Ability1", "Ability2", "Ability3"],
  ["ipfs://hash1", "ipfs://hash2", "ipfs://hash3"]
)
```

## Verifying Contract on Etherscan

1. Go to [Sepolia Etherscan](https://sepolia.etherscan.io/)
2. Find your contract address
3. Click "Verify and Publish"
4. Select: Solidity (Single file)
5. Compiler: 0.8.20
6. Paste your contract code
7. Submit

## Security Notes

🔒 **IMPORTANT:**
- Never share your private key
- The contract owner (deployer) is the only one who can mint
- Stats are stored on-chain and cannot be faked
- Only NFTs from YOUR contract address will work in the game

## Next Steps

1. Deploy to Sepolia testnet
2. Mint 3-5 test NFTs with different stats
3. Test in your game
4. When ready, deploy to Ethereum mainnet
5. Mint your full collection

## Need Help?

- [OpenZeppelin Docs](https://docs.openzeppelin.com/)
- [Remix Documentation](https://remix-ide.readthedocs.io/)
- [Hardhat Docs](https://hardhat.org/docs)

```