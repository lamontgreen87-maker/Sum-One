Origin: .gradle\caches\8.14.3\transforms\8dd563c36fdc8ed25724b885e60d3aa7\transformed\react-android-0.81.5-release\prefab (Module)

# System Guide: prefab

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)