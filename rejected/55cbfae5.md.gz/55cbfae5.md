Origin: .gradle\caches\8.14.3\transforms\e2ac816cc322e0622c8e36eeb217f096\transformed\fbjni-0.7.0\prefab\modules\fbjni\include\lyra (Module)

# System Guide: lyra

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)