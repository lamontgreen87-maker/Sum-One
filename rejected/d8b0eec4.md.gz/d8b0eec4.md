Origin: backend\venv\Lib\site-packages\pip\_internal\metadata\importlib (Module)

# System Guide: importlib

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)