Origin: _tools\hermes-dec\hermes-dec-main\src\parsers\hbc_opcodes (Module)

# System Guide: hbc_opcodes

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)