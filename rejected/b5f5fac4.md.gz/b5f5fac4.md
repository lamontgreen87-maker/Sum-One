Origin: backend\venv\Lib\site-packages\eth_abi\utils (Module)

# System Guide: utils

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)