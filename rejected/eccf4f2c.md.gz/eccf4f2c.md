Origin: backend\venv\Lib\site-packages\packaging\licenses (Module)

# System Guide: licenses

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)