Origin: backend\venv\Lib\site-packages\eth_account\signers (Module)

# System Guide: signers

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)