Origin: backend\backend\venv\Lib\site-packages\eth_hash (Module)

# System Guide: eth_hash

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)