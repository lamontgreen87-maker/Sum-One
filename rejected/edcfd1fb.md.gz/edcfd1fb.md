Origin: backend\venv\Lib\site-packages\eth_keys\backends\native (Module)

# System Guide: native

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)