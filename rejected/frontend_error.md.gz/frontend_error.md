Origin: hive_mind\frontend (Module)

# System Guide: frontend

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)