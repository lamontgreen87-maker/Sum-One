Origin: backend\venv\Lib\site-packages\pydantic\plugin (Module)

# System Guide: plugin

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)