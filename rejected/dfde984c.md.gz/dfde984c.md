Origin: backend\venv\Lib\site-packages\pytest (Module)

# System Guide: pytest

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)