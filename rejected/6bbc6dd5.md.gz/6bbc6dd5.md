Origin: sidequest-build\mobile\android\.gradle\8.9\dependencies-accessors\569c8b261a8a714d7731d5f568e0e5c05babae10\sources\org\gradle\accessors\dm (Module)

# System Guide: dm

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)