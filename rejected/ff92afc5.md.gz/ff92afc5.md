Origin: sidequest-build\mobile\android\app\build\kotlinToolingMetadata (Module)

# System Guide: kotlinToolingMetadata

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)