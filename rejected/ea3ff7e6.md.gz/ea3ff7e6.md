Origin: backend\venv\Lib\site-packages\eth_abi (Module)

# System Guide: eth_abi

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)