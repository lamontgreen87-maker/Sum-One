Origin: backend\venv\Lib\site-packages\pip\_vendor\resolvelib\compat (Module)

# System Guide: compat

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)