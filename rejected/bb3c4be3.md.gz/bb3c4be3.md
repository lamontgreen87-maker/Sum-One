Origin: backend\venv\Lib\site-packages\idna (Module)

# System Guide: idna

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)