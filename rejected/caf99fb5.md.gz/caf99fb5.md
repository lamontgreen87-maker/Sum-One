Origin: backend\venv\Lib\site-packages\pip\_internal\operations\install (Module)

# System Guide: install

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)