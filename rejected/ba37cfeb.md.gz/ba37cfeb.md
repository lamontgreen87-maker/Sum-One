Origin: backend\venv\Lib\site-packages\pip\_internal\distributions (Module)

# System Guide: distributions

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)