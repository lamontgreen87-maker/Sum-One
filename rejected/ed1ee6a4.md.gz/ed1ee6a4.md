Origin: .gradle\caches\8.14.3\transforms\8dd563c36fdc8ed25724b885e60d3aa7\transformed\react-android-0.81.5-release\prefab\modules\hermestooling\libs\android.x86 (Module)

# System Guide: android.x86

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)