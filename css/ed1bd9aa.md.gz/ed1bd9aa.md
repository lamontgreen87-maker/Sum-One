Source: hive_mind\frontend\style.css

```css
:root {
  --bg-color: #050508;
  --glass-bg: rgba(20, 20, 30, 0.6);
  --accent-primary: #00f2ff;
  --accent-secondary: #bc00ff;
  --text-primary: #ffffff;
  --text-secondary: #a0a0b0;
  --border-color: rgba(255, 255, 255, 0.1);
  --neon-glow: 0 0 15px rgba(0, 242, 255, 0.3);
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
}

body {
  background-color: var(--bg-color);
  background-image: 
    radial-gradient(circle at 10% 20%, rgba(188, 0, 255, 0.05) 0%, transparent 40%),
    radial-gradient(circle at 90% 80%, rgba(0, 242, 255, 0.05) 0%, transparent 40%);
  color: var(--text-primary);
  min-height: 100vh;
  overflow-x: hidden;
}

.dashboard {
  display: grid;
  grid-template-columns: 300px 1fr 350px;
  grid-template-rows: 80px 1fr;
  height: 100vh;
  gap: 1px;
  background: var(--border-color);
}

/* Glass Panels */
.panel {
  background: var(--glass-bg);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  padding: 20px;
  display: flex;
  flex-direction: column;
}

header {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 30px;
}

.logo {
  font-size: 24px;
  font-weight: 800;
  letter-spacing: -1px;
  background: linear-gradient(90deg, var(--accent-primary), var(--accent-secondary));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  display: flex;
  align-items: center;
  gap: 10px;
}

.logo span {
  font-size: 14px;
  font-weight: 400;
  background: rgba(255, 255, 255, 0.1);
  padding: 2px 8px;
  border-radius: 4px;
  -webkit-text-fill-color: white;
}

/* Sidebar Components */
.sidebar h3 {
  font-size: 12px;
  text-transform: uppercase;
  color: var(--text-secondary);
  letter-spacing: 2px;
  margin-bottom: 20px;
}

.nav-item {
  padding: 12px;
  border-radius: 8px;
  cursor: pointer;
  margin-bottom: 10px;
  transition: all 0.3s ease;
  border: 1px solid transparent;
}

.nav-item:hover {
  background: rgba(255, 255, 255, 0.05);
  border-color: var(--border-color);
}

.nav-item.active {
  background: rgba(0, 242, 255, 0.1);
  border-color: rgba(0, 242, 255, 0.3);
  color: var(--accent-primary);
}

/* Main View: Fractal Shatter Diagram */
.viewport {
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.shatter-viz {
  width: 100%;
  height: 100%;
  position: relative;
}

/* Right Sidebar: Consensus Monitor */
.rebuttal-feed {
  flex: 1;
  overflow-y: auto;
  font-family: 'Fira Code', monospace;
  font-size: 13px;
}

.log-entry {
  padding: 10px;
  border-bottom: 1px solid var(--border-color);
  animation: fadeIn 0.5s ease-out;
}

.log-entry.rebuttal {
  border-left: 3px solid var(--accent-secondary);
}

.log-entry.consensus {
  border-left: 3px solid var(--accent-primary);
  background: rgba(0, 242, 255, 0.05);
}

/* Input Bar */
.command-bar {
  position: absolute;
  bottom: 40px;
  left: 50%;
  transform: translateX(-50%);
  width: 600px;
  background: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(40px);
  padding: 10px;
  border-radius: 12px;
  border: 1px solid var(--border-color);
  display: flex;
  gap: 10px;
  box-shadow: 0 20px 40px rgba(0,0,0,0.5);
}

input {
  flex: 1;
  background: transparent;
  border: none;
  color: white;
  font-size: 16px;
  padding: 10px;
}

input:focus {
  outline: none;
}

button {
  background: var(--accent-primary);
  color: black;
  border: none;
  padding: 10px 20px;
  border-radius: 8px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
}

button:hover {
  transform: translateY(-2px);
  box-shadow: var(--neon-glow);
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

```