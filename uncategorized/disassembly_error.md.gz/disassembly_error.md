Origin: sidequest-build\_tools\hermes-dec\hermes-dec-main\src\disassembly (Module)

# System Guide: disassembly

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)