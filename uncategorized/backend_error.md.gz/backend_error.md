Origin: backend (Module)

# System Guide: backend

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)