Origin: backend\backend\venv\Lib\site-packages\py_ecc\fields (Module)

# System Guide: fields

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)