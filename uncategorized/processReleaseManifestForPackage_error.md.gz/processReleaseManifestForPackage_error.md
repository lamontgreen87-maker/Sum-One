Origin: sidequest-build\mobile\android\app\build\intermediates\packaged_manifests\release\processReleaseManifestForPackage (Module)

# System Guide: processReleaseManifestForPackage

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)