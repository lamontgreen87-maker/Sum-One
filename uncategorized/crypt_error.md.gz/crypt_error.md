Origin: backend\backend\venv\Lib\site-packages\google\auth\crypt (Module)

# System Guide: crypt

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)