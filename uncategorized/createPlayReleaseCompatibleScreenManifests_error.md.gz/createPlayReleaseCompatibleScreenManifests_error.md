Origin: mobile\android\app\build\intermediates\compatible_screen_manifest\playRelease\createPlayReleaseCompatibleScreenManifests (Module)

# System Guide: createPlayReleaseCompatibleScreenManifests

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)