Origin: backend\backend\venv\Lib\site-packages\eth_utils (Module)

# System Guide: eth_utils

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)