Origin: backend\backend\venv\Lib\site-packages\pip\_vendor\rich (Module)

# System Guide: rich

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)