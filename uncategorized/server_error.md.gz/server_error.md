Origin: sidequest-build\_server_zip\server (Module)

# System Guide: server

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)