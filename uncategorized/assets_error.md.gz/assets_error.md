Origin: sidequest-build\_apk_extract2\assets (Module)

# System Guide: assets

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)