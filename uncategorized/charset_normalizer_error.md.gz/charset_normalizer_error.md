Origin: backend\backend\venv\Lib\site-packages\charset_normalizer (Module)

# System Guide: charset_normalizer

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)