Origin: backend\backend\venv\Lib\site-packages\pip\_vendor\urllib3\contrib (Module)

# System Guide: contrib

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)