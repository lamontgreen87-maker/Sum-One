Origin: backend\backend\venv\Lib\site-packages\_pytest\config (Module)

# System Guide: config

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)