Origin: backend\backend\venv\Lib\site-packages\httpcore\_sync (Module)

# System Guide: _sync

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)