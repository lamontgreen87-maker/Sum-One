Origin: backend\backend\venv\Lib\site-packages\pip\_internal\commands (Module)

# System Guide: commands

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)