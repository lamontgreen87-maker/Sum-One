Origin: sidequest-build\mobile\android\app\build\intermediates\annotation_processor_list\release\javaPreCompileRelease (Module)

# System Guide: javaPreCompileRelease

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)