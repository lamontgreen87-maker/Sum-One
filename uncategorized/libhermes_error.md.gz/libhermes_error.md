Origin: .gradle\caches\8.14.3\transforms\5c678b73e2f69303c6df5ba1020627c5\transformed\hermes-android-0.81.5-release\prefab\modules\libhermes (Module)

# System Guide: libhermes

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)