Origin: frontend\src\app (Module)

# System Guide: app

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)