Origin: backend\backend\venv\Lib\site-packages\pip\_vendor\pkg_resources (Module)

# System Guide: pkg_resources

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)