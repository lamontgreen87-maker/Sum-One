Origin: mobile\android\app\build\generated\source\buildConfig\play\release\com\anonymous\dungeoncrawler (Module)

# System Guide: dungeoncrawler

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)