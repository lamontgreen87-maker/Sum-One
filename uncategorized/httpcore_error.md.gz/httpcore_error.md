Origin: backend\backend\venv\Lib\site-packages\httpcore (Module)

# System Guide: httpcore

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)