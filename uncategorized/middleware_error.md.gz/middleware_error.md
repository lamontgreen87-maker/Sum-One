Origin: backend\backend\venv\Lib\site-packages\fastapi\middleware (Module)

# System Guide: middleware

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)