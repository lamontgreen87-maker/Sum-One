Source: index.html

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Physics Game</title>
  <script>
// GameDev AI Bridge (Auto-Injected)
(function(){
  if(window.__GDA_BRIDGE_ACTIVE__) return;
  window.__GDA_BRIDGE_ACTIVE__ = true;
  let selectedUUID = null;
  let originalMaterials = new Map();
  
  // Detect if we are in the editor frame
  const isEditorFrame = window.location.search.includes("gda_mode=editor") || (window.name === "levelEditorFrame");

  if (isEditorFrame) {
    console.log("[GDA_BRIDGE] Editor mode active. Setting up orthographic view.");
    
    // Override the camera once it's available
    const setupEditorCamera = () => {
      let r = null;
      for (const k of Object.keys(window)) {
        const v = window[k];
        if (v && typeof v.setSize === "function" && v.domElement) { r = v; break; }
      }
      if (!r) return setTimeout(setupEditorCamera, 100);

      const aspect = window.innerWidth / window.innerHeight;
      const d = 10;
      const orthoCam = new THREE.OrthographicCamera(-d * aspect, d * aspect, d, -d, 0.1, 1000);
      orthoCam.position.set(0, 20, 0); // Top down
      orthoCam.lookAt(0, 0, 0);
      
      // Monkey-patch the renderer to use our camera
      const origRender = r.render.bind(r);
      r.render = (scene, camera) => {
        origRender(scene, orthoCam);
      };
      console.log("[GDA_BRIDGE] Orthographic override complete.");
    };
    
    // Wait for THREE to be defined
    const waitForThree = () => {
      if (window.THREE) setupEditorCamera();
      else setTimeout(waitForThree, 100);
    };
    waitForThree();
  }

  window.addEventListener("message", (e) => {
    const data = e.data;
    if (!data || !data.__GDA__) return;

    let s = window.scene || window._scene;
    if (!s) { for(let k in window){ try{ if(window[k] && (window[k].isScene || window[k].type==='Scene')) s=window[k]; }catch{} } }

    if (data.type === "GDA_REQ_SCENE") {
      if (s && typeof s.traverse === 'function') {
        const nodes = [];
        s.traverse(o => {
          nodes.push({ 
            uuid: o.uuid,
            name: o.name || "unnamed", 
            type: o.type, 
            visible: o.visible,
            pos: o.position ? {x:o.position.x, y:o.position.y, z:o.position.z} : null,
            rot: o.rotation ? {x:o.rotation.x, y:o.rotation.y, z:o.rotation.z} : null
          });
        });
        window.parent.postMessage({ __GDA__: true, type: "GDA_SCENE", requestId: data.requestId, result: nodes }, "*");
      }
    }

    if (data.type === "GDA_SELECT_OBJECT") {
      if (!s) return;
      // Reset previous highlight
      if (selectedUUID) {
        const prev = s.getObjectByProperty("uuid", selectedUUID);
        if (prev && prev.material && originalMaterials.has(selectedUUID)) {
          if (prev.material.emissive) {
            prev.material.emissive.copy(originalMaterials.get(selectedUUID));
          }
        }
      }
      
      selectedUUID = data.uuid;
      const obj = s.getObjectByProperty("uuid", selectedUUID);
      if (obj && obj.material && obj.material.emissive) {
        if (!originalMaterials.has(selectedUUID)) {
          originalMaterials.set(selectedUUID, obj.material.emissive.clone());
        }
        obj.material.emissive.set(0xff0000); // Glow Red
      }
    }

    if (data.type === "GDA_UPDATE_OBJECT") {
      if (!s) { console.error("[GDA_BRIDGE] No scene found for update."); return; }
      const obj = s.getObjectByProperty("uuid", data.uuid);
      if (obj) {
        if (data.pos) obj.position.set(data.pos.x, data.pos.y, data.pos.z);
        if (data.rot) obj.rotation.set(data.rot.x, data.rot.y, data.rot.z);
      } else {
        console.warn("[GDA_BRIDGE] Object not found for update:", data.uuid);
      }
    }
  });
})();
</script>
</head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>

```