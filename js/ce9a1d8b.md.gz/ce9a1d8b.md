Source: contracts\deploy-magazine.js

```js
/**
 * Magazine NFT Deployment Script
 * 
 * Prerequisites:
 * 1. MetaMask with your deployer wallet connected
 * 2. POL tokens for gas fees on Polygon Mainnet
 * 3. Contract compiled with: npx solc --base-path . --include-path node_modules --optimize --combined-json abi,bin -o build contracts/GameMagazineNFT.sol
 * 
 * Usage:
 * 1. Open browser console on your app
 * 2. Connect your wallet
 * 3. Copy and paste this script
 * 4. Call deployMagazineNFT()
 */

const MAGAZINE_NFT_BYTECODE = "YOUR_COMPILED_BYTECODE_HERE";

const MAGAZINE_NFT_ABI = [
  "constructor()",
  "function mintMagazine(tuple(address to, string name, uint8 rarity, uint8 lightningProc, uint8 poisonProc, uint8 fireProc, uint8 acidProc, uint8 silenceProc, uint8 explosiveProc, uint8 strength, uint8 dexterity, uint8 constitution, uint8 intelligence, string specialAbility) params) public returns (uint256)",
  "function updateElementalProcs(uint256 tokenId, uint8 lightningProc, uint8 poisonProc, uint8 fireProc, uint8 acidProc, uint8 silenceProc, uint8 explosiveProc) public",
  "function updateCharacterStats(uint256 tokenId, uint8 strength, uint8 dexterity, uint8 constitution, uint8 intelligence) public",
  "function updateSpecialAbility(uint256 tokenId, string memory specialAbility) public",
  "function setBaseURI(string memory baseURI) public",
  "function tokenURI(uint256 tokenId) public view returns (string memory)",
  "function getImmutableStats(uint256 tokenId) public view returns (string memory name, uint8 rarity)",
  "function getMutableStats(uint256 tokenId) public view returns (uint8 lightningProc, uint8 poisonProc, uint8 fireProc, uint8 acidProc, uint8 silenceProc, uint8 explosiveProc, uint8 strength, uint8 dexterity, uint8 constitution, uint8 intelligence, string memory specialAbility)",
  "function tokensOfOwner(address owner) public view returns (uint256[] memory)",
  "function ownerOf(uint256 tokenId) public view returns (address)",
  "function balanceOf(address owner) public view returns (uint256)",
  "function totalMinted() public view returns (uint256)"
];

async function deployMagazineNFT() {
  if (typeof window.ethereum === 'undefined') {
    console.error('MetaMask not installed!');
    return;
  }

  try {
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    const account = accounts[0];
    console.log('🔑 Connected wallet:', account);

    const chainId = await window.ethereum.request({ method: 'eth_chainId' });
    console.log('🔗 Chain ID:', parseInt(chainId, 16));
    
    if (parseInt(chainId, 16) !== 137) {
      console.error('❌ Please switch to Polygon Mainnet (Chain ID: 137)');
      return;
    }

    const { ethers } = await import('ethers');
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();

    console.log('🚀 Deploying GameMagazineNFT...');
    
    const factory = new ethers.ContractFactory(MAGAZINE_NFT_ABI, MAGAZINE_NFT_BYTECODE, signer);
    const contract = await factory.deploy();
    
    console.log('⏳ Waiting for deployment...');
    console.log('📝 Transaction hash:', contract.deploymentTransaction().hash);
    
    await contract.waitForDeployment();
    const address = await contract.getAddress();
    
    console.log('✅ GameMagazineNFT deployed!');
    console.log('📍 Contract address:', address);
    console.log('');
    console.log('🔧 Next steps:');
    console.log('1. Copy the contract address above');
    console.log('2. Update src/hooks/useMagazineNFT.js with the address');
    console.log('3. Update src/config/contracts.js with MAGAZINE_NFT_CONTRACT');
    console.log('4. Verify on PolygonScan: https://polygonscan.com/address/' + address);
    
    return address;
  } catch (error) {
    console.error('❌ Deployment failed:', error);
  }
}

console.log('Magazine NFT deployment script loaded.');
console.log('Run deployMagazineNFT() to deploy.');

```