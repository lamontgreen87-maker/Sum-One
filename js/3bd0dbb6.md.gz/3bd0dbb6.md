Source: server\ai\cli.js

```js
#!/usr/bin/env node
import { loadConfig, saveConfig } from './config.js';
import { indexProject } from './indexer.js';
import { startWatcher } from './watcher.js';
import { startAiService } from './service.js';

const command = process.argv[2] || 'help';

switch (command) {
  case 'init': {
    const config = loadConfig(process.cwd());
    saveConfig(config, process.cwd());
    console.log('AI config initialized at .ai/config.json');
    break;
  }
  case 'index': {
    const manifest = indexProject({ projectRoot: process.cwd() });
    console.log('Index complete:', manifest);
    break;
  }
  case 'watch': {
    console.log('Watching files for AI indexing...');
    startWatcher({ projectRoot: process.cwd() });
    break;
  }
  case 'start': {
    console.log('Starting AI service (index + watcher + model runner)...');
    startAiService({ projectRoot: process.cwd() });
    break;
  }
  default: {
    console.log('Usage: node server/ai/cli.js <init|index|watch|start>');
  }
}

```