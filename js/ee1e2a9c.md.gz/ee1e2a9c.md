Source: sidequest-build\mobile\src\data\dnd.js

```js
export const DEFAULT_SPELLS = [
  {
    id: "magic_missile",
    name: "Magic Missile",
    level: 1,
    school: "Evocation",
    casting_time: "1 action",
    range: "120 feet",
    duration: "Instantaneous",
    components: ["V", "S"],
    classes: ["Wizard", "Sorcerer"],
    desc: [
      "Three glowing darts of magical force automatically hit and deal 1d4+1 force damage each.",
    ],
    ritual: false,
    higher_level: ["For each slot level above 1st, the spell creates one additional dart."],
  },
  {
    id: "cure_wounds",
    name: "Cure Wounds",
    level: 1,
    school: "Evocation",
    casting_time: "1 action",
    range: "Touch",
    duration: "Instantaneous",
    components: ["V", "S"],
    classes: ["Cleric", "Paladin", "Druid", "Bard"],
    desc: ["A creature you touch regains hit points equal to 1d8 + your spellcasting ability modifier."],
    higher_level: [
      "When cast using a spell slot of 2nd level or higher, add 1d8 hit points for each slot level above 1st.",
    ],
  },
  {
    id: "shield",
    name: "Shield",
    level: 1,
    school: "Abjuration",
    casting_time: "1 reaction",
    range: "Self",
    duration: "1 round",
    components: ["V", "S"],
    classes: ["Wizard", "Sorcerer"],
    desc: [
      "An invisible barrier of magical force appears and grants +5 bonus to AC until the start of your next turn.",
    ],
    ritual: false,
  },
  {
    id: "fireball",
    name: "Fireball",
    level: 3,
    school: "Evocation",
    casting_time: "1 action",
    range: "150 feet",
    duration: "Instantaneous",
    components: ["V", "S", "M"],
    classes: ["Wizard", "Sorcerer"],
    desc: [
      "A bright streak flashes to a point you choose, then blossoms into a low roar. Each creature in 20-foot radius takes 8d6 fire damage (Dex save for half).",
    ],
    higher_level: [
      "For each slot level above 3rd, the damage increases by 1d6.",
    ],
  },
  {
    id: "hunter_s_mark",
    name: "Hunter's Mark",
    level: 1,
    school: "Divination",
    casting_time: "1 bonus action",
    range: "90 feet",
    duration: "Concentration, up to 1 hour",
    components: ["V", "S"],
    classes: ["Ranger"],
    desc: [
      "You choose a creature and deal an extra 1d6 damage whenever you hit it with a weapon attack.",
    ],
    ritual: false,
  },
  {
    id: "guidance",
    name: "Guidance",
    level: 0,
    school: "Divination",
    casting_time: "1 action",
    range: "Touch",
    duration: "Concentration, up to 1 minute",
    components: ["V", "S"],
    classes: ["Cleric", "Druid", "Bard", "Paladin"],
    desc: ["Target can add a d4 to one ability check of its choice within the duration."],
    ritual: false,
  },
];

export const DEFAULT_BESTIARY = [
  {
    id: "goblin",
    name: "Goblin",
    size: "Small",
    type: "Humanoid (goblinoid)",
    alignment: "Neutral Evil",
    armor_class: 15,
    max_hp: "7 (2d6)",
    speed: "30 ft.",
    challenge: "1/4",
    stats: { str: 8, dex: 14, con: 10, int: 10, wis: 8, cha: 8 },
    traits: [
      {
        name: "Nimble Escape",
        desc: "The goblin can take the Disengage or Hide action as a bonus action on each of its turns.",
      },
    ],
    actions: [
      {
        name: "Scimitar",
        desc: "+4 to hit, 1d6+2 slashing damage.",
      },
      {
        name: "Shortbow",
        desc: "+4 to hit, range 80/320 ft., 1d6+2 piercing damage.",
      },
    ],
    legendary_actions: [],
  },
  {
    id: "orc",
    name: "Orc",
    size: "Medium",
    type: "Humanoid (orc)",
    alignment: "Chaotic Evil",
    armor_class: 13,
    max_hp: "15 (2d8 + 6)",
    speed: "30 ft.",
    challenge: "1/2",
    stats: { str: 16, dex: 12, con: 16, int: 7, wis: 11, cha: 10 },
    traits: [
      {
        name: "Aggressive",
        desc: "The orc can move up to its speed toward a hostile creature it can see as a bonus action.",
      },
    ],
    actions: [
      {
        name: "Greataxe",
        desc: "+5 to hit, 1d12+3 slashing damage.",
      },
      {
        name: "Javelin",
        desc: "+5 to hit, 30/120 ft., 1d6+3 piercing damage.",
      },
    ],
    legendary_actions: [],
  },
  {
    id: "skeleton",
    name: "Skeleton",
    size: "Medium",
    type: "Undead",
    alignment: "Lawful Evil",
    armor_class: 13,
    max_hp: "13 (2d8 + 4)",
    speed: "30 ft.",
    challenge: "1/4",
    stats: { str: 10, dex: 14, con: 15, int: 6, wis: 8, cha: 5 },
    traits: [
      {
        name: "Undead Fortitude",
        desc: "If damage reduces the skeleton to 0 HP, make a Con save (DC 5 + damage). On success, hit points drop to 1 instead.",
      },
    ],
    actions: [
      {
        name: "Shortsword",
        desc: "+4 to hit, 1d6+2 piercing damage.",
      },
      {
        name: "Shortbow",
        desc: "+4 to hit, range 80/320 ft., 1d6+2 piercing damage.",
      },
    ],
    legendary_actions: [],
  },
];

export const DND_WEAPONS = [
  {
    id: "longsword",
    name: "Longsword",
    damage: "1d8",
    damage_type: "slashing",
    attack_ability: "str",
    finesse: false,
    classes: ["Fighter", "Paladin", "Ranger", "Barbarian"],
  },
  {
    id: "shortsword",
    name: "Shortsword",
    damage: "1d6",
    damage_type: "piercing",
    attack_ability: "dex",
    finesse: true,
    classes: ["Rogue", "Ranger", "Fighter", "Bard"],
  },
  {
    id: "greatsword",
    name: "Greatsword",
    damage: "2d6",
    damage_type: "slashing",
    attack_ability: "str",
    finesse: false,
    classes: ["Barbarian", "Fighter", "Paladin", "Ranger"],
  },
  {
    id: "greataxe",
    name: "Greataxe",
    damage: "1d12",
    damage_type: "slashing",
    attack_ability: "str",
    finesse: false,
    classes: ["Barbarian", "Fighter"],
  },
  {
    id: "scimitar",
    name: "Scimitar",
    damage: "1d6",
    damage_type: "slashing",
    attack_ability: "dex",
    finesse: true,
    classes: ["Rogue", "Ranger", "Bard"],
  },
  {
    id: "longbow",
    name: "Longbow",
    damage: "1d8",
    damage_type: "piercing",
    attack_ability: "dex",
    finesse: false,
    classes: ["Ranger", "Fighter"],
  },
  {
    id: "shortbow",
    name: "Shortbow",
    damage: "1d6",
    damage_type: "piercing",
    attack_ability: "dex",
    finesse: false,
    classes: ["Ranger", "Rogue"],
  },
  {
    id: "quarterstaff",
    name: "Quarterstaff",
    damage: "1d6",
    damage_type: "bludgeoning",
    attack_ability: "str",
    finesse: false,
    classes: ["Cleric", "Druid", "Wizard", "Monk"],
  },
  {
    id: "dagger",
    name: "Dagger",
    damage: "1d4",
    damage_type: "piercing",
    attack_ability: "dex",
    finesse: true,
    classes: ["Rogue", "Monk", "Ranger", "Bard", "Fighter"],
  },
];

export const DEFAULT_PREMADES = [
  { id: "fighter_1", name: "Brynn", klass: "Fighter", level: 3 },
  { id: "wizard_1", name: "Maelis", klass: "Wizard", level: 3 },
];

export const DEFAULT_ENEMIES = DEFAULT_BESTIARY;

```