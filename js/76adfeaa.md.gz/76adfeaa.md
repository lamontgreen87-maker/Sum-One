Source: src\config\web3modal.js

```js
import { createWeb3Modal, defaultConfig } from '@web3modal/ethers/react';

const projectId = import.meta.env.VITE_WALLETCONNECT_PROJECT_ID || '';

console.log('🔌 Web3Modal config loading...');
console.log('🔌 Project ID from env:', projectId ? 'Found (length: ' + projectId.length + ')' : 'NOT FOUND');
console.log('🔌 All VITE env vars:', Object.keys(import.meta.env).filter(k => k.startsWith('VITE_')));

const polygon = {
  chainId: 137,
  name: 'Polygon',
  currency: 'POL',
  explorerUrl: 'https://polygonscan.com',
  rpcUrl: 'https://polygon-rpc.com'
};

const metadata = {
  name: 'Physics Game',
  description: 'Web3 FPS Game with NFTs',
  url: typeof window !== 'undefined' ? window.location.origin : 'https://example.com',
  icons: ['https://avatars.githubusercontent.com/u/37784886']
};

const ethersConfig = defaultConfig({
  metadata,
  enableEIP6963: true,
  enableInjected: true,
  enableCoinbase: true,
  rpcUrl: 'https://polygon-rpc.com',
  defaultChainId: 137
});

if (projectId && projectId.length > 0) {
  console.log('🔌 Creating Web3Modal...');
  try {
    createWeb3Modal({
      ethersConfig,
      chains: [polygon],
      projectId,
      enableAnalytics: false,
      themeMode: 'dark',
      themeVariables: {
        '--w3m-accent': '#00BFFF',
        '--w3m-border-radius-master': '8px'
      }
    });
    console.log('✅ Web3Modal created successfully');
  } catch (err) {
    console.error('❌ Failed to create Web3Modal:', err);
  }
} else {
  console.warn('⚠️ WalletConnect Project ID not found. QR code connection will not work.');
  console.warn('⚠️ Please set VITE_WALLETCONNECT_PROJECT_ID environment variable');
}

export { projectId };

```