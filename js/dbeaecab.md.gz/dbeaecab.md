Source: server\ai\indexer.js

```js
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { ensureDir, getProjectAiDir } from './paths.js';
import { loadConfig } from './config.js';

function isBinaryBuffer(buffer) {
  const maxCheck = Math.min(buffer.length, 8000);
  for (let i = 0; i < maxCheck; i += 1) {
    if (buffer[i] === 0) return true;
  }
  return false;
}

function chunkText(text, chunkSize, chunkOverlap) {
  const chunks = [];
  if (!text) return chunks;

  let start = 0;
  while (start < text.length) {
    const end = Math.min(start + chunkSize, text.length);
    chunks.push({
      start,
      end,
      content: text.slice(start, end)
    });
    if (end === text.length) break;
    start = Math.max(0, end - chunkOverlap);
  }
  return chunks;
}

function sha1(input) {
  return crypto.createHash('sha1').update(input).digest('hex');
}

function shouldSkipDir(dirName, excludeSet) {
  if (excludeSet.has(dirName)) return true;
  if (dirName.startsWith('.')) return dirName !== '.well-known';
  return false;
}

function collectFiles(rootDir, includeDirs, excludeSet, extensionsSet) {
  const files = [];

  const walk = (dirPath) => {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        if (shouldSkipDir(entry.name, excludeSet)) continue;
        walk(fullPath);
        continue;
      }
      if (!entry.isFile()) continue;
      const ext = path.extname(entry.name).toLowerCase();
      if (!extensionsSet.has(ext)) continue;
      files.push(fullPath);
    }
  };

  for (const rel of includeDirs) {
    const target = path.join(rootDir, rel);
    if (fs.existsSync(target) && fs.statSync(target).isDirectory()) {
      walk(target);
    }
  }

  return files;
}

export function indexProject({ projectRoot = process.cwd(), config = null } = {}) {
  const resolvedConfig = config || loadConfig(projectRoot);
  const projectAiDir = getProjectAiDir(projectRoot);
  const indexDir = path.join(projectAiDir, 'index');
  ensureDir(indexDir);

  const excludeSet = new Set(resolvedConfig.index.exclude || []);
  const extensionsSet = new Set(resolvedConfig.index.extensions || []);
  const files = collectFiles(
    projectRoot,
    resolvedConfig.index.include || [],
    excludeSet,
    extensionsSet
  );

  const chunksPath = path.join(indexDir, 'chunks.jsonl');
  const manifestPath = path.join(indexDir, 'manifest.json');
  const out = fs.createWriteStream(chunksPath, { flags: 'w' });

  let chunkCount = 0;
  let fileCount = 0;
  const startedAt = new Date().toISOString();

  for (const filePath of files) {
    let stat;
    try {
      stat = fs.statSync(filePath);
    } catch {
      continue;
    }
    if (stat.size > resolvedConfig.index.maxFileSizeBytes) continue;

    let buffer;
    try {
      buffer = fs.readFileSync(filePath);
    } catch {
      continue;
    }
    if (isBinaryBuffer(buffer)) continue;

    const text = buffer.toString('utf-8');
    const relPath = path.relative(projectRoot, filePath);
    const fileHash = sha1(`${relPath}:${stat.size}:${stat.mtimeMs}`);
    const chunks = chunkText(
      text,
      resolvedConfig.index.chunkSize,
      resolvedConfig.index.chunkOverlap
    );

    for (const chunk of chunks) {
      const id = sha1(`${fileHash}:${chunk.start}:${chunk.end}`);
      const record = {
        id,
        path: relPath,
        start: chunk.start,
        end: chunk.end,
        content: chunk.content,
        embedding: null
      };
      out.write(`${JSON.stringify(record)}\n`);
      chunkCount += 1;
    }
    fileCount += 1;
  }

  out.end();

  const manifest = {
    startedAt,
    finishedAt: new Date().toISOString(),
    fileCount,
    chunkCount
  };
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf-8');

  return manifest;
}

```