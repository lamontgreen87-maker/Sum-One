Source: src\game\Enemy.js

```js
import * as THREE from 'three';

class Enemy extends THREE.Object3D {
    constructor(game, id, position = new THREE.Vector3()) {
        super();
        this.game = game; // Reference to GameManager or GameScene for broader context
        this.enemyId = id;
        this.name = `enemy_${id}`;

        this.health = 100;
        this.maxHealth = 100;
        this.speed = 1.0;
        this.damage = 10;
        this.isAlive = true;

        this.position.copy(position);

        // Placeholder for a visual mesh. Specific enemies will override this.
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const material = new THREE.MeshPhongMaterial({ color: 0xff0000 });
        this.mesh = new THREE.Mesh(geometry, material);
        this.add(this.mesh); // Add the mesh to the Object3D base

        console.log(`Enemy ${this.enemyId} created at ${this.position.x}, ${this.position.y}, ${this.position.z}`);
    }

    /**
     * Updates the enemy's state each frame.
     * @param {number} deltaTime - Time elapsed since last frame.
     * @param {THREE.Vector3} playerPosition - The player's current position for AI.
     */
    update(deltaTime, playerPosition) {
        if (!this.isAlive) return;

        // Basic AI: Example (specific enemies will override)
        // For now, just a placeholder.
        // E.g., move towards player, patrol, etc.
        // console.log(`Enemy ${this.id} updating...`);
    }

    /**
     * Applies damage to the enemy.
     * @param {number} amount - The amount of damage to take.
     * @returns {boolean} True if the enemy is still alive, false if dead.
     */
    takeDamage(amount) {
        if (!this.isAlive) return false;

        this.health -= amount;
        if (this.health <= 0) {
            this.health = 0;
            this.die();
            return false;
        }
        console.log(`Enemy ${this.enemyId} took ${amount} damage. Health: ${this.health}/${this.maxHealth}`);
        return true;
    }

    /**
     * Handles the enemy's death.
     */
    die() {
        if (!this.isAlive) return;
        this.isAlive = false;
        console.log(`Enemy ${this.enemyId} has died!`);
        // Remove from scene, play death animation, drop loot, etc.
        if (this.parent) {
             this.parent.remove(this); // Remove itself from its parent (the scene)
        }
        this.mesh.geometry.dispose();
        this.mesh.material.dispose();
        // Trigger a custom event for GameManager/GameScene to clean up
        this.dispatchEvent({ type: 'enemyDied', enemy: this });
    }

    /**
     * Performs an attack.
     * Specific enemies will implement their attack logic here.
     * @param {THREE.Vector3} targetPosition - The target's position.
     */
    attack(targetPosition) {
        // Placeholder for attack logic
        // console.log(`Enemy ${this.id} attacking target at ${targetPosition.x}, ${targetPosition.y}, ${targetPosition.z}`);
    }

    dispose() {
        this.mesh.geometry.dispose();
        this.mesh.material.dispose();
        this.remove(this.mesh);
    }
}

export default Enemy;

```