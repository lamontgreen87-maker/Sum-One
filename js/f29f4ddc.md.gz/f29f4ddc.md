Source: sidequest-build\_server_zip\server\starSystem.js

```js
class Vector3 {
  constructor(x = 0, y = 0, z = 0) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  
  clone() {
    return new Vector3(this.x, this.y, this.z);
  }
  
  set(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }
  
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
  }
  
  normalize() {
    const len = this.length();
    if (len > 0) {
      this.x /= len;
      this.y /= len;
      this.z /= len;
    }
    return this;
  }
  
  multiplyScalar(s) {
    this.x *= s;
    this.y *= s;
    this.z *= s;
    return this;
  }
  
  add(v) {
    this.x += v.x;
    this.y += v.y;
    this.z += v.z;
    return this;
  }
  
  sub(v) {
    this.x -= v.x;
    this.y -= v.y;
    this.z -= v.z;
    return this;
  }
  
  distanceTo(v) {
    const dx = this.x - v.x;
    const dy = this.y - v.y;
    const dz = this.z - v.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
  
  toJSON() {
    return { x: this.x, y: this.y, z: this.z };
  }
}

class StarSystemSimulation {
  constructor() {
    this.TIME_SCALE = 0.05; // How fast time passes (slower for visible orbits)
    this.BLACK_HOLE_MASS = 1000;
    
    this.PLANET_GRAVITY = {
      canyon: 1.0,
      reactor: 1.4,
      nexus: 0.55,
      euclid: 0.85,
      solaris: 0.7,
      titan: 2.5
    };
    
    // Keplerian orbital parameters for each planet
    // VERY ECCENTRIC ORBITS - distances vary dramatically day-to-day for dynamic pricing
    // Semi-major axis (a), eccentricity (e), inclination, starting angle, orbital period modifier
    this.ORBITAL_PARAMS = {
      canyon: {
        semiMajorAxis: 20,      // Average distance
        eccentricity: 0.7,      // HIGH eccentricity - varies from 6 to 34 units
        inclination: 0.1,       // Slight tilt from XZ plane
        argumentOfPeriapsis: 0, // Rotation of ellipse
        startingAngle: 0,       // Where planet starts in orbit
        periodScale: 1.2        // Orbital speed - completes orbit in ~8 real minutes
      },
      nexus: {
        semiMajorAxis: 30,
        eccentricity: 0.65,     // HIGH eccentricity - varies from 10.5 to 49.5 units
        inclination: 0.15,
        argumentOfPeriapsis: Math.PI / 3,
        startingAngle: Math.PI * 2 / 3,
        periodScale: 0.9        // ~10 real minutes
      },
      reactor: {
        semiMajorAxis: 45,
        eccentricity: 0.75,     // VERY HIGH - varies from 11.25 to 78.75 units
        inclination: 0.08,
        argumentOfPeriapsis: Math.PI * 2 / 3,
        startingAngle: Math.PI * 4 / 3,
        periodScale: 0.6        // ~14 real minutes
      },
      solaris: {
        semiMajorAxis: 60,
        eccentricity: 0.5,      // Moderate - stable star but still varies
        inclination: 0.05,
        argumentOfPeriapsis: Math.PI,
        startingAngle: Math.PI / 2,
        periodScale: 0.4        // ~20 real minutes
      },
      titan: {
        semiMajorAxis: 85,
        eccentricity: 0.6,      // Gas giant with moderate eccentricity
        inclination: 0.12,
        argumentOfPeriapsis: Math.PI * 5 / 4,
        startingAngle: Math.PI,
        periodScale: 0.25       // ~30 real minutes
      }
    };
    
    // Shuttle system configuration
    this.SHUTTLE_CONFIG = {
      seatsPerShuttle: 20,
      departureIntervalMs: 5 * 60 * 1000, // 5 minutes between departures
      maxTravelTimeMs: 2 * 60 * 1000,     // 2 minutes max travel time
      minTravelTimeMs: 15 * 1000,         // 15 seconds minimum
      baseFarePerUnit: 2,                 // HyperFuel per distance unit
      minFare: 10,                        // Minimum ticket price
      maxFare: 200                        // Maximum ticket price
    };
    
    // Active shuttle departures: Map<routeKey, shuttleData>
    this.shuttleDepartures = new Map();
    this.lastShuttleUpdate = Date.now();
    
    // Callback for when shuttle passengers arrive (set by server/index.js)
    this.onPassengersArrived = null;
    
    this.stability = 100;
    this.lastUpdate = Date.now();
    this.simulationTime = 0; // Accumulated simulation time
    this.bodies = [];
    this.barycenter = new Vector3();
    this.collisionWarning = null;
    this.approachData = {};
    this.travelDistances = {}; // Distances between planets for fuel costs
    
    this.initializeBodies();
    
    // Ensure travel distances are computed immediately for shuttle bookings
    this.updateTravelDistances();
  }
  
  // Calculate position on elliptical orbit using Kepler's equation
  getOrbitalPosition(params, time) {
    const { semiMajorAxis: a, eccentricity: e, inclination, argumentOfPeriapsis: omega, periodScale } = params;
    
    // Orbital period based on Kepler's 3rd law (simplified)
    const period = 2 * Math.PI * Math.sqrt(a * a * a / 1000) * periodScale;
    
    // Mean anomaly (angle that increases uniformly with time)
    const M = (time / period) * 2 * Math.PI;
    
    // Solve Kepler's equation for eccentric anomaly (Newton-Raphson iteration)
    let E = M;
    for (let i = 0; i < 10; i++) {
      E = E - (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
    }
    
    // True anomaly (actual angle from periapsis)
    const trueAnomaly = 2 * Math.atan2(
      Math.sqrt(1 + e) * Math.sin(E / 2),
      Math.sqrt(1 - e) * Math.cos(E / 2)
    );
    
    // Distance from focus (black hole)
    const r = a * (1 - e * e) / (1 + e * Math.cos(trueAnomaly));
    
    // Position in orbital plane
    const angle = trueAnomaly + omega;
    const x = r * Math.cos(angle);
    const z = r * Math.sin(angle);
    
    // Apply inclination (tilt the orbit)
    const y = z * Math.sin(inclination);
    const zTilted = z * Math.cos(inclination);
    
    return new Vector3(x, y, zTilted);
  }
  
  // Get orbital velocity for a planet at current position
  getOrbitalVelocity(params, time) {
    const dt = 0.01;
    const pos1 = this.getOrbitalPosition(params, time);
    const pos2 = this.getOrbitalPosition(params, time + dt);
    
    return new Vector3(
      (pos2.x - pos1.x) / dt,
      (pos2.y - pos1.y) / dt,
      (pos2.z - pos1.z) / dt
    );
  }
  
  initializeBodies() {
    this.bodies = [];
    
    // Black hole at center
    this.bodies.push({
      name: 'blackhole',
      mass: this.BLACK_HOLE_MASS,
      position: new Vector3(0, 0, 0),
      velocity: new Vector3(0, 0, 0),
      isBlackHole: true
    });
    
    // Initialize planets with their orbital parameters
    const planetNames = ['canyon', 'nexus', 'reactor', 'solaris', 'titan'];
    
    planetNames.forEach(name => {
      const params = this.ORBITAL_PARAMS[name];
      const startTime = params.startingAngle / (2 * Math.PI) * 100; // Convert angle to time offset
      
      const position = this.getOrbitalPosition(params, startTime);
      const velocity = this.getOrbitalVelocity(params, startTime);
      
      this.bodies.push({
        name,
        mass: name === 'titan' ? 40 : (name === 'reactor' ? 45 : (name === 'canyon' ? 30 : (name === 'nexus' ? 20 : 15))),
        position,
        velocity,
        orbitalParams: params,
        orbitalTime: startTime,
        isStar: name === 'solaris',
        isGasGiant: name === 'titan',
        chaosState: { isWobbling: false, wobbleIntensity: 0 }
      });
    });
    
    // Euclid Station - fixed circular orbit (space station with thrusters)
    const euclidRadius = 35;
    this.bodies.push({
      name: 'euclid',
      mass: 5,
      position: new Vector3(euclidRadius, 5, 0),
      velocity: new Vector3(0, 0, Math.sqrt(1000 / euclidRadius)),
      isStation: true,
      orbitalRadius: euclidRadius,
      orbitalAngle: 0,
      orbitalHeight: 5
    });
    
    this.logOrbitalInfo();
  }
  
  logOrbitalInfo() {
    console.log('🌌 Star system initialized with elliptical orbits:');
    
    Object.entries(this.ORBITAL_PARAMS).forEach(([name, params]) => {
      const perihelion = params.semiMajorAxis * (1 - params.eccentricity);
      const aphelion = params.semiMajorAxis * (1 + params.eccentricity);
      console.log(`  ${name}: perihelion=${perihelion.toFixed(1)}, aphelion=${aphelion.toFixed(1)}, e=${params.eccentricity}`);
    });
    
    console.log('  euclid: circular orbit at r=35 (station)');
  }
  
  update() {
    const now = Date.now();
    const deltaMs = now - this.lastUpdate;
    this.lastUpdate = now;
    
    const deltaTime = Math.min(deltaMs / 1000, 0.1);
    const dt = deltaTime * this.TIME_SCALE;
    
    // Advance simulation time
    this.simulationTime += dt;
    
    // Update each planet's position along its elliptical orbit
    this.bodies.forEach(body => {
      if (body.isBlackHole) return;
      
      if (body.isStation) {
        // Euclid station - simple circular orbit
        body.orbitalAngle += dt * 0.5;
        body.position.x = body.orbitalRadius * Math.cos(body.orbitalAngle);
        body.position.z = body.orbitalRadius * Math.sin(body.orbitalAngle);
        body.position.y = body.orbitalHeight;
        return;
      }
      
      if (body.orbitalParams) {
        // Advance orbital time
        body.orbitalTime += dt;
        
        // Get new position on ellipse
        const newPos = this.getOrbitalPosition(body.orbitalParams, body.orbitalTime);
        const newVel = this.getOrbitalVelocity(body.orbitalParams, body.orbitalTime);
        
        body.position = newPos;
        body.velocity = newVel;
        body.currentRadius = newPos.length();
      }
    });
    
    // Calculate distances between all planets for fuel costs
    this.updateTravelDistances();
    
    // Update approach data for UI
    this.updateApproachData();
  }
  
  updateTravelDistances() {
    const planets = this.bodies.filter(b => !b.isBlackHole);
    
    this.travelDistances = {};
    
    for (let i = 0; i < planets.length; i++) {
      for (let j = i + 1; j < planets.length; j++) {
        const a = planets[i];
        const b = planets[j];
        const distance = a.position.distanceTo(b.position);
        
        const key = [a.name, b.name].sort().join('-');
        this.travelDistances[key] = {
          distance: distance,
          fuelCost: this.calculateFuelCost(distance),
          bodies: [a.name, b.name]
        };
      }
    }
  }
  
  calculateFuelCost(distance) {
    // Base fuel cost: 1 HyperFuel per 5 units of distance
    // Minimum cost: 5 HyperFuel
    // Maximum cost: 100 HyperFuel (for very long distances)
    const baseCost = Math.ceil(distance / 5);
    return Math.max(5, Math.min(100, baseCost));
  }
  
  getTravelInfo(fromPlanet, toPlanet) {
    const key = [fromPlanet, toPlanet].sort().join('-');
    const info = this.travelDistances[key];
    
    if (!info) {
      return { distance: 0, fuelCost: 0, error: 'Invalid planets' };
    }
    
    return {
      from: fromPlanet,
      to: toPlanet,
      distance: Math.round(info.distance * 10) / 10,
      fuelCost: info.fuelCost
    };
  }
  
  getAllTravelInfo() {
    const result = {};
    
    Object.entries(this.travelDistances).forEach(([key, info]) => {
      result[key] = {
        distance: Math.round(info.distance * 10) / 10,
        fuelCost: info.fuelCost
      };
    });
    
    return result;
  }
  
  updateApproachData() {
    const planets = this.bodies.filter(b => !b.isBlackHole && !b.isStation && !b.isStar && !b.isGasGiant);
    
    for (let i = 0; i < planets.length; i++) {
      for (let j = i + 1; j < planets.length; j++) {
        const a = planets[i];
        const b = planets[j];
        const key = [a.name, b.name].sort().join('-');
        const distance = a.position.distanceTo(b.position);
        
        this.approachData[key] = {
          distance,
          urgency: distance < 10 ? 'critical' : (distance < 20 ? 'warning' : 'safe'),
          isConverging: false // Simplified - elliptical orbits are predictable
        };
      }
    }
  }
  
  // ============================================
  // SHUTTLE SYSTEM METHODS
  // ============================================
  
  // Calculate travel time based on distance (scales linearly, capped at max)
  calculateTravelTime(distance) {
    const { maxTravelTimeMs, minTravelTimeMs } = this.SHUTTLE_CONFIG;
    
    // Max possible distance in our system (roughly 170 units when planets at opposite ends)
    const maxDistance = 170;
    
    // Linear interpolation between min and max travel time
    const ratio = Math.min(distance / maxDistance, 1);
    const travelTime = minTravelTimeMs + (maxTravelTimeMs - minTravelTimeMs) * ratio;
    
    return Math.round(travelTime);
  }
  
  // Calculate ticket price based on current distance
  calculateTicketPrice(distance) {
    const { baseFarePerUnit, minFare, maxFare } = this.SHUTTLE_CONFIG;
    const price = Math.ceil(distance * baseFarePerUnit);
    return Math.max(minFare, Math.min(maxFare, price));
  }
  
  // Get the route key for two planets (alphabetically sorted)
  getRouteKey(from, to) {
    return [from, to].sort().join('-');
  }
  
  // Get or create shuttle departure for a route
  getOrCreateShuttle(from, to) {
    const routeKey = `${from}->${to}`;
    const now = Date.now();
    
    let shuttle = this.shuttleDepartures.get(routeKey);
    
    // Check if we need a new shuttle (none exists or current one has departed)
    if (!shuttle || shuttle.departureTime <= now) {
      // Get current distance for pricing and timing
      const travelKey = this.getRouteKey(from, to);
      const travelInfo = this.travelDistances[travelKey];
      
      if (!travelInfo) {
        return null;
      }
      
      const distance = travelInfo.distance;
      const travelTimeMs = this.calculateTravelTime(distance);
      const ticketPrice = this.calculateTicketPrice(distance);
      
      // Calculate staggered departure time
      // Shuttles depart every 5 minutes, but stagger based on route to spread out arrivals
      const routeHash = routeKey.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
      const staggerOffset = (routeHash % 12) * 25000; // 0-5 minute offset in 25s increments
      
      const baseInterval = this.SHUTTLE_CONFIG.departureIntervalMs;
      const nextDepartureTime = Math.ceil((now + staggerOffset) / baseInterval) * baseInterval;
      
      shuttle = {
        routeKey,
        from,
        to,
        departureTime: nextDepartureTime,
        arrivalTime: nextDepartureTime + travelTimeMs,
        travelTimeMs,
        distance: Math.round(distance * 10) / 10,
        ticketPrice,
        seatsTotal: this.SHUTTLE_CONFIG.seatsPerShuttle,
        seatsAvailable: this.SHUTTLE_CONFIG.seatsPerShuttle,
        passengers: [], // Array of { walletAddress, bookedAt }
        status: 'boarding' // boarding, in-transit, arrived
      };
      
      this.shuttleDepartures.set(routeKey, shuttle);
      console.log(`🚌 New shuttle scheduled: ${from} → ${to} departing at ${new Date(nextDepartureTime).toISOString()}`);
    }
    
    return shuttle;
  }
  
  // Book a seat on a shuttle
  bookShuttleTicket(from, to, walletAddress) {
    const shuttle = this.getOrCreateShuttle(from, to);
    
    if (!shuttle) {
      return { success: false, error: 'Invalid route' };
    }
    
    if (shuttle.status !== 'boarding') {
      return { success: false, error: 'Shuttle has already departed' };
    }
    
    // Check if already booked
    if (shuttle.passengers.find(p => p.walletAddress.toLowerCase() === walletAddress.toLowerCase())) {
      return { success: false, error: 'Already booked on this shuttle' };
    }
    
    if (shuttle.seatsAvailable <= 0) {
      return { success: false, error: 'Shuttle is full' };
    }
    
    // Book the seat
    shuttle.passengers.push({
      walletAddress: walletAddress.toLowerCase(),
      bookedAt: Date.now()
    });
    shuttle.seatsAvailable--;
    
    console.log(`🎟️ Ticket booked: ${walletAddress.slice(0, 8)}... on ${from} → ${to}`);
    
    return {
      success: true,
      ticket: {
        from,
        to,
        departureTime: shuttle.departureTime,
        arrivalTime: shuttle.arrivalTime,
        travelTimeMs: shuttle.travelTimeMs,
        ticketPrice: shuttle.ticketPrice,
        seatNumber: shuttle.seatsTotal - shuttle.seatsAvailable,
        seatsRemaining: shuttle.seatsAvailable
      }
    };
  }
  
  // Cancel a shuttle booking
  cancelShuttleTicket(from, to, walletAddress) {
    const routeKey = `${from}->${to}`;
    const shuttle = this.shuttleDepartures.get(routeKey);
    
    if (!shuttle) {
      return { success: false, error: 'No shuttle found' };
    }
    
    if (shuttle.status !== 'boarding') {
      return { success: false, error: 'Cannot cancel after departure' };
    }
    
    const passengerIndex = shuttle.passengers.findIndex(
      p => p.walletAddress.toLowerCase() === walletAddress.toLowerCase()
    );
    
    if (passengerIndex === -1) {
      return { success: false, error: 'No booking found' };
    }
    
    shuttle.passengers.splice(passengerIndex, 1);
    shuttle.seatsAvailable++;
    
    return { success: true, refundAmount: shuttle.ticketPrice };
  }
  
  // Get all available shuttles from a location
  getShuttlesFromLocation(from) {
    const destinations = ['canyon', 'nexus', 'reactor', 'euclid', 'solaris', 'titan'];
    const shuttles = [];
    
    for (const to of destinations) {
      if (to === from) continue;
      
      const shuttle = this.getOrCreateShuttle(from, to);
      if (shuttle) {
        shuttles.push({
          to,
          departureTime: shuttle.departureTime,
          arrivalTime: shuttle.arrivalTime,
          travelTimeMs: shuttle.travelTimeMs,
          distance: shuttle.distance,
          ticketPrice: shuttle.ticketPrice,
          seatsAvailable: shuttle.seatsAvailable,
          seatsTotal: shuttle.seatsTotal,
          status: shuttle.status,
          timeUntilDeparture: Math.max(0, shuttle.departureTime - Date.now())
        });
      }
    }
    
    // Sort by departure time
    shuttles.sort((a, b) => a.departureTime - b.departureTime);
    
    return shuttles;
  }
  
  // Check if a player is on a shuttle that has departed
  getPlayerTravelStatus(walletAddress) {
    const normalizedWallet = walletAddress.toLowerCase();
    
    for (const [routeKey, shuttle] of this.shuttleDepartures) {
      const passenger = shuttle.passengers.find(
        p => p.walletAddress === normalizedWallet
      );
      
      if (passenger) {
        const now = Date.now();
        
        if (shuttle.departureTime > now) {
          return {
            isTraveling: false,
            isBooked: true,
            from: shuttle.from,
            to: shuttle.to,
            departureTime: shuttle.departureTime,
            timeUntilDeparture: shuttle.departureTime - now
          };
        } else if (shuttle.arrivalTime > now) {
          return {
            isTraveling: true,
            from: shuttle.from,
            to: shuttle.to,
            departureTime: shuttle.departureTime,
            arrivalTime: shuttle.arrivalTime,
            progress: (now - shuttle.departureTime) / shuttle.travelTimeMs,
            timeRemaining: shuttle.arrivalTime - now
          };
        } else {
          // Arrived - player should be at destination
          return {
            isTraveling: false,
            justArrived: true,
            destination: shuttle.to
          };
        }
      }
    }
    
    return { isTraveling: false, isBooked: false };
  }
  
  // Update shuttle statuses (call periodically)
  updateShuttles() {
    const now = Date.now();
    
    for (const [routeKey, shuttle] of this.shuttleDepartures) {
      if (shuttle.status === 'boarding' && shuttle.departureTime <= now) {
        shuttle.status = 'in-transit';
        console.log(`🚀 Shuttle departed: ${shuttle.from} → ${shuttle.to} with ${shuttle.passengers.length} passengers`);
      } else if (shuttle.status === 'in-transit' && shuttle.arrivalTime <= now) {
        shuttle.status = 'arrived';
        console.log(`🛬 Shuttle arrived: ${shuttle.from} → ${shuttle.to}`);
        
        // Update passenger locations via callback (if set by server/index.js)
        // Extract wallet addresses from passenger objects
        if (this.onPassengersArrived && shuttle.passengers.length > 0) {
          const walletAddresses = shuttle.passengers.map(p => p.walletAddress);
          this.onPassengersArrived(walletAddresses, shuttle.to);
        }
        
        // Clear arrived shuttles after a short delay
        setTimeout(() => {
          if (this.shuttleDepartures.get(routeKey)?.status === 'arrived') {
            this.shuttleDepartures.delete(routeKey);
          }
        }, 30000);
      }
    }
  }
  
  // Get full shuttle schedule for the star system
  getShuttleSchedule() {
    const schedule = {};
    const destinations = ['canyon', 'nexus', 'reactor', 'euclid', 'solaris', 'titan'];
    
    for (const from of destinations) {
      schedule[from] = this.getShuttlesFromLocation(from);
    }
    
    return schedule;
  }
  
  getState() {
    const bodiesState = {};
    this.bodies.forEach(body => {
      bodiesState[body.name] = {
        position: body.position.toJSON(),
        velocity: body.velocity.toJSON(),
        mass: body.mass,
        isBlackHole: body.isBlackHole || false,
        isStation: body.isStation || false,
        isStar: body.isStar || false,
        isGasGiant: body.isGasGiant || false,
        chaosState: body.chaosState || null,
        orbitalParams: body.orbitalParams || null,
        currentRadius: body.currentRadius || body.position.length()
      };
    });
    
    // Update shuttle statuses before returning state
    this.updateShuttles();
    
    return {
      bodies: bodiesState,
      stability: this.stability,
      timestamp: Date.now(),
      barycenter: this.barycenter.toJSON(),
      approachData: this.approachData,
      planetGravity: this.PLANET_GRAVITY,
      collisionWarning: this.collisionWarning,
      travelDistances: this.getAllTravelInfo(),
      shuttleConfig: {
        seatsPerShuttle: this.SHUTTLE_CONFIG.seatsPerShuttle,
        departureIntervalMs: this.SHUTTLE_CONFIG.departureIntervalMs,
        maxTravelTimeMs: this.SHUTTLE_CONFIG.maxTravelTimeMs
      }
    };
  }
  
  serializeForDB() {
    return JSON.stringify(this.getState());
  }
  
  loadFromDB(stateData) {
    try {
      const state = typeof stateData === 'string' ? JSON.parse(stateData) : stateData;
      
      if (state.bodies) {
        Object.entries(state.bodies).forEach(([name, data]) => {
          const body = this.bodies.find(b => b.name === name);
          if (body) {
            body.position = new Vector3(data.position.x, data.position.y, data.position.z);
            body.velocity = new Vector3(data.velocity.x, data.velocity.y, data.velocity.z);
            if (data.orbitalParams) {
              body.orbitalParams = data.orbitalParams;
            }
            if (data.chaosState) {
              body.chaosState = data.chaosState;
            }
          }
        });
      }
      
      if (typeof state.stability === 'number') {
        this.stability = state.stability;
      }
      
      console.log(`📥 Star system state loaded, stability: ${this.stability.toFixed(1)}%`);
      return true;
    } catch (error) {
      console.error('Failed to load star system state:', error);
      return false;
    }
  }
  
  stabilizePlanet(planetName, walletAddress) {
    const planet = this.bodies.find(b => b.name === planetName);
    if (!planet || planet.isBlackHole || planet.isStation) {
      return { success: false, error: 'Invalid planet' };
    }
    
    // Bonus stability based on planet
    const bonuses = {
      canyon: 20,
      nexus: 25,
      reactor: 30,
      solaris: 15,
      titan: 10
    };
    
    const bonus = bonuses[planetName] || 15;
    this.stability = Math.min(100, this.stability + bonus);
    
    console.log(`🔧 ${walletAddress} stabilized ${planetName}, +${bonus}% stability (now ${this.stability.toFixed(1)}%)`);
    
    return {
      success: true,
      planet: planetName,
      stabilityBonus: bonus,
      newStability: this.stability
    };
  }
}

export default StarSystemSimulation;
export { Vector3 };

```