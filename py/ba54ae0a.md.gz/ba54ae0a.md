Source: backend\backend\venv\Lib\site-packages\pip\_vendor\resolvelib\compat\__init__.py

```py

```