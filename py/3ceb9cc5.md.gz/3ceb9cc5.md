Source: backend\backend\venv\Lib\site-packages\uvicorn\lifespan\__init__.py

```py

```