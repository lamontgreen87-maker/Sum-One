Source: backend\backend\venv\Lib\site-packages\anyio\streams\__init__.py

```py

```