Source: backend\backend\venv\Lib\site-packages\pyasn1\__init__.py

```py
# https://www.python.org/dev/peps/pep-0396/
__version__ = '0.6.1'

```