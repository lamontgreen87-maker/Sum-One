Source: backend\backend\venv\Lib\site-packages\eth_abi\utils\__init__.py

```py

```