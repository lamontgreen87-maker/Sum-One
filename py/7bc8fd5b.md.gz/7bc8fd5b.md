Source: backend\backend\venv\Lib\site-packages\uvicorn\__main__.py

```py
import uvicorn

if __name__ == "__main__":
    uvicorn.main()

```