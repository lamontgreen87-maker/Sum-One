Source: _tools\hermes-dec\hermes-dec-main\hbc_file_parser.py

```py
#!/usr/bin/python3
#-*- encoding: Utf-8 -*-

from src.parsers.hbc_file_parser import main

main()

```