Source: backend\__init__.py

```py
# Package marker for backend modules.

```