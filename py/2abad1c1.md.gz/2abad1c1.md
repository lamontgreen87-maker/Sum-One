Source: backend\venv\Lib\site-packages\fastapi\middleware\wsgi.py

```py
from starlette.middleware.wsgi import WSGIMiddleware as WSGIMiddleware  # noqa

```