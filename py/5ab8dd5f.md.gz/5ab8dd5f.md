Source: backend\venv\Lib\site-packages\fastapi\staticfiles.py

```py
from starlette.staticfiles import StaticFiles as StaticFiles  # noqa

```