Source: backend\venv\Lib\site-packages\eth_hash\__init__.py

```py
from importlib.metadata import (
    version as __version,
)

from .main import (
    Keccak256,
)

__version__ = __version("eth-hash")

```