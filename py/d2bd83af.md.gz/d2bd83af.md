Source: backend\backend\venv\Lib\site-packages\pip\_vendor\certifi\__init__.py

```py
from .core import contents, where

__all__ = ["contents", "where"]
__version__ = "2024.07.04"

```