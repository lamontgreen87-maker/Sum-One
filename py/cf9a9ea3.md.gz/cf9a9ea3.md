Source: backend\backend\venv\Lib\site-packages\fastapi\middleware\trustedhost.py

```py
from starlette.middleware.trustedhost import (  # noqa
    TrustedHostMiddleware as TrustedHostMiddleware,
)

```