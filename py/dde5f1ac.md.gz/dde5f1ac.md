Source: backend\backend\venv\Lib\site-packages\eth_keys\__init__.py

```py
from importlib.metadata import (
    version as __version,
)

from .main import (
    KeyAPI,
    lazy_key_api as keys,
)

__version__ = __version("eth-keys")

```