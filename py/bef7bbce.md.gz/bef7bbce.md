Source: backend\venv\Lib\site-packages\idna\package_data.py

```py
__version__ = "3.11"

```