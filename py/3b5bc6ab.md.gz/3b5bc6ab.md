Source: backend\venv\Lib\site-packages\pip\_vendor\urllib3\_version.py

```py
# This file is protected via CODEOWNERS
__version__ = "1.26.18"

```