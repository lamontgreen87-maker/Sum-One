Source: backend\venv\Lib\site-packages\Crypto\__init__.py

```py
__all__ = ['Cipher', 'Hash', 'Protocol', 'PublicKey', 'Util', 'Signature',
           'IO', 'Math']

version_info = (3, 23, '0')

__version__ = ".".join([str(x) for x in version_info])

```