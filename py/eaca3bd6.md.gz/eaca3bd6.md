Source: backend\venv\Lib\site-packages\pydantic\deprecated\__init__.py

```py

```