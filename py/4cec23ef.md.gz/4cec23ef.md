Source: backend\backend\venv\Lib\site-packages\httpcore\_backends\__init__.py

```py

```