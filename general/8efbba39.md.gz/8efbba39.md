Origin: mobile\android\app\build\outputs\apk\play\release (Module)

# System Guide: release

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)