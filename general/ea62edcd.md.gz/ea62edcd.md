Origin: sidequest-build\mobile\android\app\build\intermediates\signing_config_versions\release\writeReleaseSigningConfigVersions (Module)

# System Guide: writeReleaseSigningConfigVersions

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)