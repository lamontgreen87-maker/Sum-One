Origin: backend\venv\Lib\site-packages\pip\_internal\resolution (Module)

# System Guide: resolution

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)