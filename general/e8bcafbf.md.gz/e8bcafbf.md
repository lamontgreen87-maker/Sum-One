Origin: mobile\android\app\build\intermediates\optimized_processed_res\playRelease\optimizePlayReleaseResources (Module)

# System Guide: optimizePlayReleaseResources

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)