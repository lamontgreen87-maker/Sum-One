Origin: backend\venv\Lib\site-packages\anyio\_core (Module)

# System Guide: _core

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)