Origin: backend\backend\venv\Lib\site-packages\py_ecc\secp256k1 (Module)

# System Guide: secp256k1

Module analysis failed: model 'qwen2.5-coder:7b' not found (status code: 404)