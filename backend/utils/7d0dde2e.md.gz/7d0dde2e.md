Origin: hive_mind\coding_benchmark_results.json

# How-To: coding_benchmark_results.json

# How-To Guide for Python Functions and Classes

## Simple Function

### Overview

A simple function is a reusable piece of code that performs a specific task. This guide will help you create a function to filter even numbers from a given list.

### Example Code

```python
def filter_even_numbers(numbers: list) -> list:
    """
    Takes a list of integers as input and returns a new list containing only the even numbers.

    Parameters:
        numbers (list): A list of integer values.

    Returns:
        list: A list containing only even numbers from the input list.
    """

    def is_even(number):
        return number % 2 == 0

    # Filter out even numbers using the helper function `is_even`
    filtered_numbers = [num for num in numbers if is_even(num)]

    return filtered_numbers
```

### How to Use

1. Define a list of integers.
2. Call the `filter_even_numbers` function with the list as its argument.
3. The function will return a new list containing only the even numbers.

```python
numbers_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
even_numbers = filter_even_numbers(numbers_list)
print(even_numbers)  # Output: [2, 4, 6, 8]
```

### Explanation

- **Helper Function**: The `is_even` function checks if a number is even.
- **List Comprehension**: The list comprehension `[num for num in numbers if is_even(num)]` filters out the even numbers from the input list.

## Class Design

### Overview

A class is a blueprint for creating objects. This guide will help you create a simple `TaskQueue` class with methods to add tasks, retrieve and mark them as complete.

### Example Code

```python
class TaskQueue:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        """
        Adds a new task to the queue.

        Parameters:
            task (callable): A function or callable object that represents a task. It should not take any arguments and should return None.
        
        Returns:
            None
        
        Raises:
            TypeError: If the provided task is not callable.
        """
        if not callable(task):
            raise TypeError("The task must be a callable object.")

        self.tasks.append((task, None))

    def get_next_task(self):
        """
        Retrieves and removes the next available task from the queue to process it.

        Returns:
            tuple: A tuple containing the function (callable) that represents the task and its status (True if completed).
        
        Raises:
            IndexError: If there are no more tasks in the queue.
        """
        try:
            # Get the first element of the current list, which is a tuple with (task, None)
            return self.tasks.pop(0)[0], False
        except IndexError:
            raise IndexError("No more tasks available in the queue.")

    def mark_complete(self):
        """
        Marks the last task as completed.
        
        Returns:
            None
        
        Raises:
            IndexError: If there are no tasks in the queue to mark as complete.
        """
        try:
            self.tasks[-1] = (self.tasks[-1][0], True)
        except IndexError:
            raise IndexError("No tasks available in the queue.")
```

### How to Use

1. Create an instance of the `TaskQueue` class.
2. Add tasks using the `add_task` method.
3. Retrieve and process tasks using the `get_next_task` method.
4. Mark a task as complete using the `mark_complete` method.

```python
task_queue = TaskQueue()
task_queue.add_task(lambda: print("Task 1"))
task_queue.add_task(lambda: print("Task 2"))

next_task, completed = task_queue.get_next_task()
print(next_task())  # Output: Task 1
print(completed)     # Output: False

task_queue.mark_complete()

next_task, completed = task_queue.get_next_task()
print(next_task())  # Output: Task 2
print(completed)     # Output: False
```

### Explanation

- **Constructor (`__init__`)**: Initializes an empty list to store tasks.
- **Add Task**: Adds a new task to the queue and checks if it's callable.
- **Get Next Task**: Retrieves the next available task from the queue and marks it as incomplete.
- **Mark Complete**: Marks the last task in the queue as completed.