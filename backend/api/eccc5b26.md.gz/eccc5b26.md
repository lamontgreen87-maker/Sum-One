Origin: hive_mind\api_server.py

# How-To: api_server.py

# How-To Guide for `api_server.py`

## Introduction

This guide provides a step-by-step overview of the `api_server.py` file, which is designed to manage and operate a distributed computing system using FastAPI. The API facilitates worker registration, heartbeat updates, task completion reporting, and swarm execution.

## Prerequisites

Before you begin, ensure you have the following installed:

- Python 3.x
- FastAPI (`pip install fastapi`)
- Uvicorn (`pip install uvicorn`)
- Pydantic (`pip install pydantic`)
- Other dependencies such as `overmind` and `telemetry`

## Directory Structure

```
/project_root/
├── api_server.py
├── dashboard/
│   └── index.html
└── worker_nexus.py
```

## Key Components

1. **FastAPI Setup**: The API is built using FastAPI, which provides a modern, fast (high-performance), web framework for building APIs with Python 3.7+ based on standard Python type hints.

2. **Static Files**: The `/dashboard` directory serves static files like `index.html`.

3. **CORS Middleware**: CORS middleware is added to allow cross-origin requests from any domain.

4. **Worker Registration and Heartbeat**: Endpoints for worker registration (`/worker/register`) and heartbeat updates (`/worker/heartbeat/{worker_id}`). These endpoints help manage worker availability and performance.

5. **Task Completion Reporting**: The `/worker/complete` endpoint records the completion of tasks by workers, updating their performance scores and payout credits.

6. **Swarm Execution**: The `/swarm/execute` endpoint initiates a swarm execution task based on user requests. It runs in the background using `BackgroundTasks`.

7. **Task Status Retrieval**: The `/swarm/status/{task_id}` endpoint allows retrieval of the status of specific tasks.

## Running the API

1. **Start the Uvicorn Server**:
   ```bash
   uvicorn api_server:app --reload
   ```

2. **Access the Dashboard**:
   Open your browser and navigate to `http://localhost:8000/dashboard` to access the dashboard.

3. **Interact with API Endpoints**:
   - Use tools like Postman or curl to interact with the API endpoints.
   - Example of registering a worker:
     ```bash
     curl -X POST "http://localhost:8000/worker/register" -H "Content-Type: application/json" -d '{"name": "Worker1", "vram_gb": 16, "total_slots": 4, "model_name": "ModelA", "endpoint_url": "http://worker1.local"}'
     ```

## Notes

- Ensure that the `worker_nexus.py` file is correctly configured and accessible by the API.
- The code includes telemetry and logging mechanisms (`telemetry`, `LoopGuard`) to monitor system performance.
- For production use, consider adding more robust error handling, authentication, and security measures.

This guide should help you understand and utilize the functionalities provided by the `api_server.py` file effectively.