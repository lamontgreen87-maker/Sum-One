Origin: hive_mind\direct_shatter_test.py

# How-To: direct_shatter_test.py

# How-To Guide for `direct_shatter_test.py`

This guide provides a step-by-step explanation on how to run the `direct_shatter_test.py` script, which is used for testing the decomposition of a goal into tasks using an Overmind system.

## Prerequisites
1. **Python Environment**: Ensure you have Python installed on your machine. It is recommended to use Python 3.8 or later.
2. **Dependencies**: Install the required dependencies by running:
   ```bash
   pip install overmind asyncio
   ```
3. **Environment Variable**: Set the `OLLAMA_URL` environment variable to point to the correct API endpoint if it's different from the default (`http://localhost:11434/api/generate`).

## Running the Script
Follow these steps to run the script:

1. **Save the Code**: Save the provided code snippet into a file named `direct_shatter_test.py`.

2. **Set Environment Variable (Optional)**:
   If you need to override the default `OLLAMA_URL`, set it in your environment before running the script:
   ```bash
   export OLLAMA_URL=http://your-api-url:port/api/generate
   ```

3. **Run the Script**:
   Execute the script using the Python interpreter:
   ```bash
   python direct_shatter_test.py
   ```

## Expected Output
When you run the script, you should see output similar to the following:

```
--- DIRECT SHATTER TEST ---
OLLAMA_URL: http://localhost:11434/api/generate
Goal: Create a task manager app with a dark mode UI and user authentication.
Shattering...
[2023-04-01 12:34:56,789] INFO: [direct_shatter_test.py] Goal decomposition initiated.
[2023-04-01 12:34:56,789] DEBUG: [direct_shatter_test.py] Decomposing goal into tasks.
[2023-04-01 12:34:56,789] INFO: [direct_shatter_test.py] Goal decomposition completed successfully.

--- SHATTER RESULT ---
[1] (Tier 1): Create a task manager app
[2] (Tier 2): Implement dark mode UI
[3] (Tier 3): Add user authentication
```

## Error Handling
If there is an error during the execution of the script, you might see output similar to:

```
CRITICAL ERROR: <error_message>
```

Common errors include:
- **Network Issues**: If `OLLAMA_URL` is incorrect or unreachable.
- **Dependency Errors**: Missing or incorrectly installed dependencies.

## Troubleshooting
If you encounter issues, check the following:
- Ensure that the Overmind service is running and accessible at the specified URL.
- Verify that all required Python packages are correctly installed using `pip install overmind asyncio`.

By following these steps, you should be able to successfully run and understand the functionality of the `direct_shatter_test.py` script.