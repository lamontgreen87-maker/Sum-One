Source: .gradle\caches\8.14.3\transforms\8dd563c36fdc8ed25724b885e60d3aa7\transformed\react-android-0.81.5-release\prefab\modules\reactnative\libs\android.x86\abi.json

```json
{
  "abi": "x86",
  "api": 24,
  "ndk": 27,
  "stl": "c++_shared",
  "static": false
}
```