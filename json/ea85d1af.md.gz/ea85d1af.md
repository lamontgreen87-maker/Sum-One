Source: mobile\android\app\build\intermediates\java_res\playRelease\processPlayReleaseJavaRes\out\kotlin-tooling-metadata.json

```json
{
  "schemaVersion": "1.1.0",
  "buildSystem": "Gradle",
  "buildSystemVersion": "8.10.2",
  "buildPlugin": "org.jetbrains.kotlin.gradle.plugin.KotlinAndroidPluginWrapper",
  "buildPluginVersion": "1.9.25",
  "projectSettings": {
    "isHmppEnabled": true,
    "isCompatibilityMetadataVariantEnabled": false,
    "isKPMEnabled": false
  },
  "projectTargets": [
    {
      "target": "org.jetbrains.kotlin.gradle.plugin.mpp.KotlinAndroidTarget",
      "platformType": "androidJvm",
      "extras": {
        "android": {
          "sourceCompatibility": "17",
          "targetCompatibility": "17"
        }
      }
    }
  ]
}
```