Source: sidequest-build\mobile\android\app\build\intermediates\merged_manifests\release\processReleaseManifest\output-metadata.json

```json
{
  "version": 3,
  "artifactType": {
    "type": "MERGED_MANIFESTS",
    "kind": "Directory"
  },
  "applicationId": "com.anonymous.dungeoncrawler",
  "variantName": "release",
  "elements": [
    {
      "type": "SINGLE",
      "filters": [],
      "attributes": [],
      "versionCode": 2,
      "versionName": "0.1.5",
      "outputFile": "AndroidManifest.xml"
    }
  ],
  "elementType": "File"
}
```