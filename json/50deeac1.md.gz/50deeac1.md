Source: sidequest-build\mobile\android\app\build\intermediates\merged_res_blame_folder\release\mergeReleaseResources\out\multi-v2\values-v18.json

```json
{
    "logs": [
        {
            "outputFile": "com.anonymous.dungeoncrawler.app-mergeReleaseResources-41:/values-v18/values-v18.xml",
            "map": [
                {
                    "source": "C:\\sc\\.gradle\\caches\\8.14.3\\transforms\\c65f12be68c2613c49b7122117912132\\transformed\\appcompat-1.7.0\\res\\values-v18\\values-v18.xml",
                    "from": {
                        "startLines": "2",
                        "startColumns": "4",
                        "startOffsets": "55",
                        "endColumns": "48",
                        "endOffsets": "99"
                    }
                }
            ]
        }
    ]
}
```