Source: mobile\android\app\build\intermediates\merged_res_blame_folder\playRelease\mergePlayReleaseResources\out\multi-v2\values-hy.json

```json
{
    "logs": [
        {
            "outputFile": "com.anonymous.dungeoncrawler.app-mergePlayReleaseResources-53:/values-hy/values-hy.xml",
            "map": [
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\61d536ed561733f97dd659a2ddb856ef\\transformed\\ui-release\\res\\values-hy\\values-hy.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,204,286,380,480,563,645,731,826,908,993,1081,1155,1232,1311,1388,1469,1538",
                        "endColumns": "98,81,93,99,82,81,85,94,81,84,87,73,76,78,76,80,68,117",
                        "endOffsets": "199,281,375,475,558,640,726,821,903,988,1076,1150,1227,1306,1383,1464,1533,1651"
                    },
                    "to": {
                        "startLines": "36,37,58,59,60,66,67,70,71,72,73,75,76,77,79,82,83,84",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "3534,3633,6211,6305,6405,6953,7035,7261,7356,7438,7523,7694,7768,7845,7999,8251,8332,8401",
                        "endColumns": "98,81,93,99,82,81,85,94,81,84,87,73,76,78,76,80,68,117",
                        "endOffsets": "3628,3710,6300,6400,6483,7030,7116,7351,7433,7518,7606,7763,7840,7919,8071,8327,8396,8514"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\727d5f8568bea8c800ecbfb67dbfe934\\transformed\\browser-1.2.0\\res\\values-hy\\values-hy.xml",
                    "from": {
                        "startLines": "2,3,4,5",
                        "startColumns": "4,4,4,4",
                        "startOffsets": "55,159,262,373",
                        "endColumns": "103,102,110,101",
                        "endOffsets": "154,257,368,470"
                    },
                    "to": {
                        "startLines": "57,61,62,63",
                        "startColumns": "4,4,4,4",
                        "startOffsets": "6107,6488,6591,6702",
                        "endColumns": "103,102,110,101",
                        "endOffsets": "6206,6586,6697,6799"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\168558c8b26b86308b25cf5137046d4d\\transformed\\core-1.13.1\\res\\values-hy\\values-hy.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "55,155,260,358,457,562,664,775",
                        "endColumns": "99,104,97,98,104,101,110,100",
                        "endOffsets": "150,255,353,452,557,659,770,871"
                    },
                    "to": {
                        "startLines": "29,30,31,32,33,34,35,81",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "2814,2914,3019,3117,3216,3321,3423,8150",
                        "endColumns": "99,104,97,98,104,101,110,100",
                        "endOffsets": "2909,3014,3112,3211,3316,3418,3529,8246"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\5b3abb9f9b4bacf15b4212ab7576afa0\\transformed\\appcompat-1.6.1\\res\\values-hy\\values-hy.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,213,313,423,512,618,735,817,897,988,1081,1176,1270,1370,1463,1558,1652,1743,1834,1917,2023,2129,2228,2338,2446,2547,2717,2814",
                        "endColumns": "107,99,109,88,105,116,81,79,90,92,94,93,99,92,94,93,90,90,82,105,105,98,109,107,100,169,96,82",
                        "endOffsets": "208,308,418,507,613,730,812,892,983,1076,1171,1265,1365,1458,1553,1647,1738,1829,1912,2018,2124,2223,2333,2441,2542,2712,2809,2892"
                    },
                    "to": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,74",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,213,313,423,512,618,735,817,897,988,1081,1176,1270,1370,1463,1558,1652,1743,1834,1917,2023,2129,2228,2338,2446,2547,2717,7611",
                        "endColumns": "107,99,109,88,105,116,81,79,90,92,94,93,99,92,94,93,90,90,82,105,105,98,109,107,100,169,96,82",
                        "endOffsets": "208,308,418,507,613,730,812,892,983,1076,1171,1265,1365,1458,1553,1647,1738,1829,1912,2018,2124,2223,2333,2441,2542,2712,2809,7689"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\c1b2bdbafd2ca6d74b523c9c81b176ff\\transformed\\react-android-0.76.6-release\\res\\values-hy\\values-hy.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8",
                        "startColumns": "4,4,4,4,4,4,4",
                        "startOffsets": "55,132,200,281,349,421,496",
                        "endColumns": "76,67,80,67,71,74,73",
                        "endOffsets": "127,195,276,344,416,491,565"
                    },
                    "to": {
                        "startLines": "38,64,65,68,69,78,80",
                        "startColumns": "4,4,4,4,4,4,4",
                        "startOffsets": "3715,6804,6872,7121,7189,7924,8076",
                        "endColumns": "76,67,80,67,71,74,73",
                        "endOffsets": "3787,6867,6948,7184,7256,7994,8145"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\322e005fb7384ca41aaea870471f9aa7\\transformed\\play-services-basement-18.5.0\\res\\values-hy\\values.xml",
                    "from": {
                        "startLines": "4",
                        "startColumns": "0",
                        "startOffsets": "195",
                        "endColumns": "146",
                        "endOffsets": "341"
                    },
                    "to": {
                        "startLines": "47",
                        "startColumns": "4",
                        "startOffsets": "4835",
                        "endColumns": "150",
                        "endOffsets": "4981"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\13155f0bb311dfe00b99967b082feea4\\transformed\\foundation-release\\res\\values-hy\\values-hy.xml",
                    "from": {
                        "startLines": "2,3",
                        "startColumns": "4,4",
                        "startOffsets": "55,140",
                        "endColumns": "84,88",
                        "endOffsets": "135,224"
                    },
                    "to": {
                        "startLines": "85,86",
                        "startColumns": "4,4",
                        "startOffsets": "8519,8604",
                        "endColumns": "84,88",
                        "endOffsets": "8599,8688"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\ef1d2ec04ff1d5d261aef1501e5f76be\\transformed\\play-services-base-18.5.0\\res\\values-hy\\values.xml",
                    "from": {
                        "startLines": "4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20",
                        "startColumns": "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0",
                        "startOffsets": "193,295,456,586,690,840,972,1095,1204,1367,1471,1635,1767,1925,2087,2148,2211",
                        "endColumns": "101,160,129,103,149,131,122,108,162,103,163,131,157,161,60,62,77",
                        "endOffsets": "294,455,585,689,839,971,1094,1203,1366,1470,1634,1766,1924,2086,2147,2210,2288"
                    },
                    "to": {
                        "startLines": "39,40,41,42,43,44,45,46,48,49,50,51,52,53,54,55,56",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "3792,3898,4063,4197,4305,4459,4595,4722,4986,5153,5261,5429,5565,5727,5893,5958,6025",
                        "endColumns": "105,164,133,107,153,135,126,112,166,107,167,135,161,165,64,66,81",
                        "endOffsets": "3893,4058,4192,4300,4454,4590,4717,4830,5148,5256,5424,5560,5722,5888,5953,6020,6102"
                    }
                }
            ]
        }
    ]
}
```