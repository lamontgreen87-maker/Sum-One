Source: sidequest-build\.gradle\caches\8.14.3\transforms\5c678b73e2f69303c6df5ba1020627c5\transformed\hermes-android-0.81.5-release\prefab\modules\libhermes\libs\android.x86\abi.json

```json
{
  "abi": "x86",
  "api": 24,
  "ndk": 27,
  "stl": "c++_shared",
  "static": false
}
```