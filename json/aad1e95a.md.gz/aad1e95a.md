Source: dist\levels\nexus.json

```json
{
  "name": "Nexus Zone",
  "description": "High-altitude alignment hub near the portal",
  "bounds": { "x": 100, "z": 100 },
  "gravity": 0.55,
  "jumpVelocity": 5.5,
  "ambientColor": "0x201040",
  "fogColor": "0x1a0a35",
  "skyColor": "0x2a1050",
  
  "floor": {
    "color": "0x201030",
    "segments": 20,
    "roughness": 0.5,
    "materialRoughness": 0.8,
    "metalness": 0.1
  },
  
  "spawnPoints": [
    { "x": 40, "y": 2, "z": 40, "team": "blue" },
    { "x": -40, "y": 2, "z": -40, "team": "red" },
    { "x": 40, "y": 2, "z": -40, "team": "blue" },
    { "x": -40, "y": 2, "z": 40, "team": "red" }
  ],
  
  "navPoints": [
    { "x": -20, "y": 0, "z": 0 },
    { "x": 20, "y": 0, "z": 0 },
    { "x": 0, "y": 0, "z": -20 },
    { "x": 0, "y": 0, "z": 20 },
    { "x": -15, "y": 0, "z": -15 },
    { "x": 15, "y": 0, "z": 15 },
    { "x": -15, "y": 0, "z": 15 },
    { "x": 15, "y": 0, "z": -15 },
    { "x": -30, "y": 0, "z": 0 },
    { "x": 30, "y": 0, "z": 0 },
    { "x": 0, "y": 0, "z": -30 },
    { "x": 0, "y": 0, "z": 30 }
  ],
  
  "cylinders": [
    { "x": -20, "z": 0, "radius": 1.5, "height": 6, "color": "0x6020a0", "emissive": "0x4010a0", "emissiveIntensity": 0.3, "isCover": true },
    { "x": 20, "z": 0, "radius": 1.5, "height": 6, "color": "0x6020a0", "emissive": "0x4010a0", "emissiveIntensity": 0.3, "isCover": true },
    { "x": 0, "z": -20, "radius": 1.5, "height": 6, "color": "0x6020a0", "emissive": "0x4010a0", "emissiveIntensity": 0.3, "isCover": true },
    { "x": 0, "z": 20, "radius": 1.5, "height": 6, "color": "0x6020a0", "emissive": "0x4010a0", "emissiveIntensity": 0.3, "isCover": true },
    { "x": -15, "z": -15, "radius": 1.2, "height": 5, "color": "0x5018a0", "emissive": "0x3010a0", "emissiveIntensity": 0.2, "isCover": true },
    { "x": 15, "z": 15, "radius": 1.2, "height": 5, "color": "0x5018a0", "emissive": "0x3010a0", "emissiveIntensity": 0.2, "isCover": true },
    { "x": -15, "z": 15, "radius": 1.2, "height": 5, "color": "0x5018a0", "emissive": "0x3010a0", "emissiveIntensity": 0.2, "isCover": true },
    { "x": 15, "z": -15, "radius": 1.2, "height": 5, "color": "0x5018a0", "emissive": "0x3010a0", "emissiveIntensity": 0.2, "isCover": true },
    { "x": -30, "z": 0, "radius": 2, "height": 8, "color": "0x7030b0", "emissive": "0x5020b0", "emissiveIntensity": 0.4, "isCover": true },
    { "x": 30, "z": 0, "radius": 2, "height": 8, "color": "0x7030b0", "emissive": "0x5020b0", "emissiveIntensity": 0.4, "isCover": true },
    { "x": 0, "z": -30, "radius": 2, "height": 8, "color": "0x7030b0", "emissive": "0x5020b0", "emissiveIntensity": 0.4, "isCover": true },
    { "x": 0, "z": 30, "radius": 2, "height": 8, "color": "0x7030b0", "emissive": "0x5020b0", "emissiveIntensity": 0.4, "isCover": true }
  ],
  
  "boxes": [
    { "x": -25, "z": -25, "width": 6, "height": 3, "depth": 2, "color": "0x302050", "emissive": "0x201040", "emissiveIntensity": 0.2, "isCover": true },
    { "x": 25, "z": 25, "width": 6, "height": 3, "depth": 2, "color": "0x302050", "emissive": "0x201040", "emissiveIntensity": 0.2, "isCover": true },
    { "x": -25, "z": 25, "width": 2, "height": 3, "depth": 6, "color": "0x302050", "emissive": "0x201040", "emissiveIntensity": 0.2, "isCover": true },
    { "x": 25, "z": -25, "width": 2, "height": 3, "depth": 6, "color": "0x302050", "emissive": "0x201040", "emissiveIntensity": 0.2, "isCover": true },
    { "x": -35, "z": -35, "width": 4, "height": 2, "depth": 4, "color": "0x252035", "isCover": true },
    { "x": 35, "z": 35, "width": 4, "height": 2, "depth": 4, "color": "0x252035", "isCover": true },
    { "x": -35, "z": 35, "width": 4, "height": 2, "depth": 4, "color": "0x252035", "isCover": true },
    { "x": 35, "z": -35, "width": 4, "height": 2, "depth": 4, "color": "0x252035", "isCover": true }
  ],
  
  "walls": [
    { "x": 0, "z": -48, "width": 100, "height": 5, "depth": 4, "color": "0x1a1025" },
    { "x": 0, "z": 48, "width": 100, "height": 5, "depth": 4, "color": "0x1a1025" },
    { "x": -48, "z": 0, "width": 4, "height": 5, "depth": 100, "color": "0x1a1025" },
    { "x": 48, "z": 0, "width": 4, "height": 5, "depth": 100, "color": "0x1a1025" }
  ],
  
  "decorations": [
    {
      "type": "torus",
      "x": 0, "y": 20, "z": 0,
      "radius": 10,
      "tube": 2,
      "radialSegments": 8,
      "tubularSegments": 64,
      "color": "0xaa00ff",
      "emissive": "0xaa00ff",
      "emissiveIntensity": 2,
      "transparent": true,
      "opacity": 0.7,
      "userData": { "isPortal": true }
    },
    {
      "type": "cylinder",
      "x": 35, "y": 0, "z": 0,
      "radius": 1,
      "height": 8,
      "color": "0x00ffff",
      "emissive": "0x00ffff",
      "emissiveIntensity": 0.3,
      "userData": { "isAlignmentArray": true }
    }
  ],
  
  "lights": [
    { "type": "point", "x": 0, "y": 20, "z": 0, "color": "0xaa00ff", "intensity": 2, "distance": 50 },
    { "type": "point", "x": 35, "y": 8, "z": 0, "color": "0x00ffff", "intensity": 1.5, "distance": 20 },
    { "type": "point", "x": -30, "y": 10, "z": 0, "color": "0x6020a0", "intensity": 1, "distance": 25 },
    { "type": "point", "x": 30, "y": 10, "z": 0, "color": "0x6020a0", "intensity": 1, "distance": 25 },
    { "type": "point", "x": 0, "y": 10, "z": -30, "color": "0x6020a0", "intensity": 1, "distance": 25 },
    { "type": "point", "x": 0, "y": 10, "z": 30, "color": "0x6020a0", "intensity": 1, "distance": 25 }
  ]
}

```