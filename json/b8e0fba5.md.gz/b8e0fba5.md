Source: server-registry\servers.json

```json
{
    "version": "1.0",
    "lastUpdated": "2026-01-20",
    "servers": [
        {
            "id": "official-free",
            "name": "Official SideQuest Server",
            "description": "Free community server by the creator. 1000 free credits to start!",
            "url": "https://your-runpod-url.cloud",
            "pricing": "Free",
            "status": "online",
            "owner": "Lamont Green",
            "tags": [
                "official",
                "free",
                "english"
            ],
            "passwordProtected": false
        },
        {
            "id": "default-2",
            "name": "default",
            "description": "basic",
            "url": "https://ohagmnlrcu843y-8000.proxy.runpod.net",
            "pricing": "free",
            "status": "online",
            "owner": "lamont",
            "tags": [
                "community",
                "new"
            ],
            "passwordProtected": false
        }
    ]
}
```