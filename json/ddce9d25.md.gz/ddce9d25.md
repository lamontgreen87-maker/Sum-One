Source: sidequest-build\mobile\android\app\build\intermediates\merged_res_blame_folder\release\mergeReleaseResources\out\multi-v2\values-be.json

```json
{
    "logs": [
        {
            "outputFile": "com.anonymous.dungeoncrawler.app-mergeReleaseResources-41:/values-be/values-be.xml",
            "map": [
                {
                    "source": "C:\\sc\\.gradle\\caches\\8.14.3\\transforms\\8dd563c36fdc8ed25724b885e60d3aa7\\transformed\\react-android-0.81.5-release\\res\\values-be\\values-be.xml",
                    "from": {
                        "startLines": "2,3,4,5,6",
                        "startColumns": "4,4,4,4,4",
                        "startOffsets": "55,138,209,294,365",
                        "endColumns": "82,70,84,70,66",
                        "endOffsets": "133,204,289,360,427"
                    },
                    "to": {
                        "startLines": "36,37,38,39,40",
                        "startColumns": "4,4,4,4,4",
                        "startOffsets": "3566,3649,3720,3805,3876",
                        "endColumns": "82,70,84,70,66",
                        "endOffsets": "3644,3715,3800,3871,3938"
                    }
                },
                {
                    "source": "C:\\sc\\.gradle\\caches\\8.14.3\\transforms\\c65f12be68c2613c49b7122117912132\\transformed\\appcompat-1.7.0\\res\\values-be\\values-be.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,225,328,444,530,635,754,834,911,1003,1097,1192,1286,1381,1475,1571,1666,1758,1850,1931,2037,2142,2240,2348,2454,2562,2735,2835",
                        "endColumns": "119,102,115,85,104,118,79,76,91,93,94,93,94,93,95,94,91,91,80,105,104,97,107,105,107,172,99,81",
                        "endOffsets": "220,323,439,525,630,749,829,906,998,1092,1187,1281,1376,1470,1566,1661,1753,1845,1926,2032,2137,2235,2343,2449,2557,2730,2830,2912"
                    },
                    "to": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,41",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,225,328,444,530,635,754,834,911,1003,1097,1192,1286,1381,1475,1571,1666,1758,1850,1931,2037,2142,2240,2348,2454,2562,2735,3943",
                        "endColumns": "119,102,115,85,104,118,79,76,91,93,94,93,94,93,95,94,91,91,80,105,104,97,107,105,107,172,99,81",
                        "endOffsets": "220,323,439,525,630,749,829,906,998,1092,1187,1281,1376,1470,1566,1661,1753,1845,1926,2032,2137,2235,2343,2449,2557,2730,2830,4020"
                    }
                },
                {
                    "source": "C:\\sc\\.gradle\\caches\\8.14.3\\transforms\\5ea28536f77f2e786673fadf58593de7\\transformed\\core-1.13.1\\res\\values-be\\values-be.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "55,153,255,355,456,562,665,786",
                        "endColumns": "97,101,99,100,105,102,120,100",
                        "endOffsets": "148,250,350,451,557,660,781,882"
                    },
                    "to": {
                        "startLines": "29,30,31,32,33,34,35,42",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "2835,2933,3035,3135,3236,3342,3445,4025",
                        "endColumns": "97,101,99,100,105,102,120,100",
                        "endOffsets": "2928,3030,3130,3231,3337,3440,3561,4121"
                    }
                }
            ]
        }
    ]
}
```