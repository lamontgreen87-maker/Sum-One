Source: mobile\android\app\build\intermediates\merged_res_blame_folder\playRelease\mergePlayReleaseResources\out\multi-v2\values-ne.json

```json
{
    "logs": [
        {
            "outputFile": "com.anonymous.dungeoncrawler.app-mergePlayReleaseResources-53:/values-ne/values-ne.xml",
            "map": [
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\5b3abb9f9b4bacf15b4212ab7576afa0\\transformed\\appcompat-1.6.1\\res\\values-ne\\values-ne.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,214,325,433,524,631,751,835,914,1005,1098,1193,1287,1387,1480,1575,1669,1760,1851,1937,2050,2151,2247,2360,2470,2587,2754,2865",
                        "endColumns": "108,110,107,90,106,119,83,78,90,92,94,93,99,92,94,93,90,90,85,112,100,95,112,109,116,166,110,79",
                        "endOffsets": "209,320,428,519,626,746,830,909,1000,1093,1188,1282,1382,1475,1570,1664,1755,1846,1932,2045,2146,2242,2355,2465,2582,2749,2860,2940"
                    },
                    "to": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,74",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,214,325,433,524,631,751,835,914,1005,1098,1193,1287,1387,1480,1575,1669,1760,1851,1937,2050,2151,2247,2360,2470,2587,2754,7718",
                        "endColumns": "108,110,107,90,106,119,83,78,90,92,94,93,99,92,94,93,90,90,85,112,100,95,112,109,116,166,110,79",
                        "endOffsets": "209,320,428,519,626,746,830,909,1000,1093,1188,1282,1382,1475,1570,1664,1755,1846,1932,2045,2146,2242,2355,2465,2582,2749,2860,7793"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\168558c8b26b86308b25cf5137046d4d\\transformed\\core-1.13.1\\res\\values-ne\\values-ne.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "55,158,261,363,469,567,667,775",
                        "endColumns": "102,102,101,105,97,99,107,100",
                        "endOffsets": "153,256,358,464,562,662,770,871"
                    },
                    "to": {
                        "startLines": "29,30,31,32,33,34,35,81",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "2865,2968,3071,3173,3279,3377,3477,8234",
                        "endColumns": "102,102,101,105,97,99,107,100",
                        "endOffsets": "2963,3066,3168,3274,3372,3472,3580,8330"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\13155f0bb311dfe00b99967b082feea4\\transformed\\foundation-release\\res\\values-ne\\values-ne.xml",
                    "from": {
                        "startLines": "2,3",
                        "startColumns": "4,4",
                        "startOffsets": "55,140",
                        "endColumns": "84,90",
                        "endOffsets": "135,226"
                    },
                    "to": {
                        "startLines": "85,86",
                        "startColumns": "4,4",
                        "startOffsets": "8604,8689",
                        "endColumns": "84,90",
                        "endOffsets": "8684,8775"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\61d536ed561733f97dd659a2ddb856ef\\transformed\\ui-release\\res\\values-ne\\values-ne.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,204,294,388,485,571,653,749,836,922,1012,1105,1182,1257,1330,1402,1483,1551",
                        "endColumns": "98,89,93,96,85,81,95,86,85,89,92,76,74,72,71,80,67,119",
                        "endOffsets": "199,289,383,480,566,648,744,831,917,1007,1100,1177,1252,1325,1397,1478,1546,1666"
                    },
                    "to": {
                        "startLines": "36,37,58,59,60,66,67,70,71,72,73,75,76,77,79,82,83,84",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "3585,3684,6285,6379,6476,7049,7131,7362,7449,7535,7625,7798,7875,7950,8093,8335,8416,8484",
                        "endColumns": "98,89,93,96,85,81,95,86,85,89,92,76,74,72,71,80,67,119",
                        "endOffsets": "3679,3769,6374,6471,6557,7126,7222,7444,7530,7620,7713,7870,7945,8018,8160,8411,8479,8599"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\322e005fb7384ca41aaea870471f9aa7\\transformed\\play-services-basement-18.5.0\\res\\values-ne\\values.xml",
                    "from": {
                        "startLines": "4",
                        "startColumns": "0",
                        "startOffsets": "195",
                        "endColumns": "159",
                        "endOffsets": "354"
                    },
                    "to": {
                        "startLines": "47",
                        "startColumns": "4",
                        "startOffsets": "4893",
                        "endColumns": "163",
                        "endOffsets": "5052"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\727d5f8568bea8c800ecbfb67dbfe934\\transformed\\browser-1.2.0\\res\\values-ne\\values-ne.xml",
                    "from": {
                        "startLines": "2,3,4,5",
                        "startColumns": "4,4,4,4",
                        "startOffsets": "55,162,274,388",
                        "endColumns": "106,111,113,113",
                        "endOffsets": "157,269,383,497"
                    },
                    "to": {
                        "startLines": "57,61,62,63",
                        "startColumns": "4,4,4,4",
                        "startOffsets": "6178,6562,6674,6788",
                        "endColumns": "106,111,113,113",
                        "endOffsets": "6280,6669,6783,6897"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\ef1d2ec04ff1d5d261aef1501e5f76be\\transformed\\play-services-base-18.5.0\\res\\values-ne\\values.xml",
                    "from": {
                        "startLines": "4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20",
                        "startColumns": "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0",
                        "startOffsets": "193,300,454,584,697,864,996,1102,1203,1379,1489,1649,1778,1922,2070,2132,2200",
                        "endColumns": "106,153,129,112,166,131,105,100,175,109,159,128,143,147,61,67,87",
                        "endOffsets": "299,453,583,696,863,995,1101,1202,1378,1488,1648,1777,1921,2069,2131,2199,2287"
                    },
                    "to": {
                        "startLines": "39,40,41,42,43,44,45,46,48,49,50,51,52,53,54,55,56",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "3851,3962,4120,4254,4371,4542,4678,4788,5057,5237,5351,5515,5648,5796,5948,6014,6086",
                        "endColumns": "110,157,133,116,170,135,109,104,179,113,163,132,147,151,65,71,91",
                        "endOffsets": "3957,4115,4249,4366,4537,4673,4783,4888,5232,5346,5510,5643,5791,5943,6009,6081,6173"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\c1b2bdbafd2ca6d74b523c9c81b176ff\\transformed\\react-android-0.76.6-release\\res\\values-ne\\values-ne.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8",
                        "startColumns": "4,4,4,4,4,4,4",
                        "startOffsets": "55,132,200,279,347,414,484",
                        "endColumns": "76,67,78,67,66,69,68",
                        "endOffsets": "127,195,274,342,409,479,548"
                    },
                    "to": {
                        "startLines": "38,64,65,68,69,78,80",
                        "startColumns": "4,4,4,4,4,4,4",
                        "startOffsets": "3774,6902,6970,7227,7295,8023,8165",
                        "endColumns": "76,67,78,67,66,69,68",
                        "endOffsets": "3846,6965,7044,7290,7357,8088,8229"
                    }
                }
            ]
        }
    ]
}
```