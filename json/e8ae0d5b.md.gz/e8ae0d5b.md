Source: sidequest-build\.gradle\caches\8.14.3\transforms\8dd563c36fdc8ed25724b885e60d3aa7\transformed\react-android-0.81.5-release\prefab\modules\hermestooling\module.json

```json
{
  "export_libraries": [],
  "android": {}
}
```