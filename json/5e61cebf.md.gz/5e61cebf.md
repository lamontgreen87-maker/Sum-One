Source: public\shield-metadata\2.json

```json
{
  "name": "Energy Shield #2",
  "description": "Common energy shield NFT from the Physics Game collection. This shield provides reliable energy-based protection with on-chain stats.",
  "image": "https://bf7534a0-2f96-4e11-bb00-c72a6ed56e04-00-3uwy3akqm4nbm.spock.replit.dev/energy_shield_nft.png",
  "external_url": "https://polygonscan.com/token/0x1306Cd717d74d09ee57ffC55E188D71C6d61cF5E?a=2",
  "attributes": [
    {"trait_type": "Edition", "value": "Common"},
    {"trait_type": "Rarity", "value": "Common"},
    {"trait_type": "Shield Type", "value": "Energy"}
  ]
}

```