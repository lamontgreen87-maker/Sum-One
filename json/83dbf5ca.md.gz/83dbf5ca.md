Source: package.json

```json
{
  "name": "physics-game",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "powershell -ExecutionPolicy Bypass -File scripts/start-dev.ps1",
    "dev:client": "vite --host 0.0.0.0",
    "start": "npm run dev",
    "server": "node server/index.js",
    "server:ensure": "powershell -ExecutionPolicy Bypass -File scripts/ensure-server.ps1",
    "build": "vite build",
    "preview": "vite preview",
    "deploy:ships": "node scripts/deploy-ships.cjs",
    "ai:init": "node server/ai/cli.js init",
    "ai:index": "node server/ai/cli.js index",
    "ai:watch": "node server/ai/cli.js watch",
    "ai:start": "node server/ai/cli.js start"
  },
  "dependencies": {
    "@gltf-transform/cli": "^4.2.1",
    "@openzeppelin/contracts": "^5.4.0",
    "@phosphor-icons/webcomponents": "^2.1.5",
    "@walletconnect/ethereum-provider": "^2.23.0",
    "@web3modal/ethers": "^5.1.11",
    "adm-zip": "^0.5.16",
    "cors": "^2.8.5",
    "dotenv": "^17.2.3",
    "ethers": "^6.15.0",
    "express": "^5.1.0",
    "fbx2gltf": "^0.9.7-p1",
    "gltf-pipeline": "^4.3.0",
    "node-cron": "^4.2.1",
    "pg": "^8.16.3",
    "qrcode": "^1.5.4",
    "qrcode-terminal": "^0.12.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "socket.io": "^4.8.1",
    "socket.io-client": "^4.8.1",
    "solc": "^0.8.30",
    "three": "^0.160.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer": "^10.4.17",
    "postcss": "^8.4.35",
    "tailwindcss": "^3.4.1",
    "vite": "^5.1.0"
  }
}

```