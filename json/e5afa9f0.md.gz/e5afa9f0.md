Source: mobile\android\app\build\intermediates\merged_res_blame_folder\playRelease\mergePlayReleaseResources\out\multi-v2\values-is.json

```json
{
    "logs": [
        {
            "outputFile": "com.anonymous.dungeoncrawler.app-mergePlayReleaseResources-53:/values-is/values-is.xml",
            "map": [
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\13155f0bb311dfe00b99967b082feea4\\transformed\\foundation-release\\res\\values-is\\values-is.xml",
                    "from": {
                        "startLines": "2,3",
                        "startColumns": "4,4",
                        "startOffsets": "55,142",
                        "endColumns": "86,86",
                        "endOffsets": "137,224"
                    },
                    "to": {
                        "startLines": "78,79",
                        "startColumns": "4,4",
                        "startOffsets": "7758,7845",
                        "endColumns": "86,86",
                        "endOffsets": "7840,7927"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\5b3abb9f9b4bacf15b4212ab7576afa0\\transformed\\appcompat-1.6.1\\res\\values-is\\values-is.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,205,302,414,499,600,714,795,874,965,1058,1151,1245,1351,1444,1539,1634,1725,1819,1900,2010,2117,2214,2323,2423,2526,2681,2779",
                        "endColumns": "99,96,111,84,100,113,80,78,90,92,92,93,105,92,94,94,90,93,80,109,106,96,108,99,102,154,97,80",
                        "endOffsets": "200,297,409,494,595,709,790,869,960,1053,1146,1240,1346,1439,1534,1629,1720,1814,1895,2005,2112,2209,2318,2418,2521,2676,2774,2855"
                    },
                    "to": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,69",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,205,302,414,499,600,714,795,874,965,1058,1151,1245,1351,1444,1539,1634,1725,1819,1900,2010,2117,2214,2323,2423,2526,2681,7017",
                        "endColumns": "99,96,111,84,100,113,80,78,90,92,92,93,105,92,94,94,90,93,80,109,106,96,108,99,102,154,97,80",
                        "endOffsets": "200,297,409,494,595,709,790,869,960,1053,1146,1240,1346,1439,1534,1629,1720,1814,1895,2005,2112,2209,2318,2418,2521,2676,2774,7093"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\ef1d2ec04ff1d5d261aef1501e5f76be\\transformed\\play-services-base-18.5.0\\res\\values-is\\values.xml",
                    "from": {
                        "startLines": "4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20",
                        "startColumns": "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0",
                        "startOffsets": "193,295,445,566,671,808,929,1034,1135,1285,1387,1540,1662,1800,1950,2010,2069",
                        "endColumns": "101,149,120,104,136,120,104,100,149,101,152,121,137,149,59,58,74",
                        "endOffsets": "294,444,565,670,807,928,1033,1134,1284,1386,1539,1661,1799,1949,2009,2068,2143"
                    },
                    "to": {
                        "startLines": "38,39,40,41,42,43,44,45,47,48,49,50,51,52,53,54,55",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "3668,3774,3928,4053,4162,4303,4428,4537,4771,4925,5031,5188,5314,5456,5610,5674,5737",
                        "endColumns": "105,153,124,108,140,124,108,104,153,105,156,125,141,153,63,62,78",
                        "endOffsets": "3769,3923,4048,4157,4298,4423,4532,4637,4920,5026,5183,5309,5451,5605,5669,5732,5811"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\727d5f8568bea8c800ecbfb67dbfe934\\transformed\\browser-1.2.0\\res\\values-is\\values-is.xml",
                    "from": {
                        "startLines": "2,3,4,5",
                        "startColumns": "4,4,4,4",
                        "startOffsets": "55,159,260,366",
                        "endColumns": "103,100,105,99",
                        "endOffsets": "154,255,361,461"
                    },
                    "to": {
                        "startLines": "56,60,61,62",
                        "startColumns": "4,4,4,4",
                        "startOffsets": "5816,6203,6304,6410",
                        "endColumns": "103,100,105,99",
                        "endOffsets": "5915,6299,6405,6505"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\61d536ed561733f97dd659a2ddb856ef\\transformed\\ui-release\\res\\values-is\\values-is.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "105,196,277,376,475,560,640,735,824,906,984,1067,1137,1212,1287,1361,1438,1506",
                        "endColumns": "90,80,98,98,84,79,94,88,81,77,82,69,74,74,73,76,67,119",
                        "endOffsets": "191,272,371,470,555,635,730,819,901,979,1062,1132,1207,1282,1356,1433,1501,1621"
                    },
                    "to": {
                        "startLines": "36,37,57,58,59,63,64,65,66,67,68,70,71,72,73,75,76,77",
                        "startColumns": "4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4",
                        "startOffsets": "3496,3587,5920,6019,6118,6510,6590,6685,6774,6856,6934,7098,7168,7243,7318,7493,7570,7638",
                        "endColumns": "90,80,98,98,84,79,94,88,81,77,82,69,74,74,73,76,67,119",
                        "endOffsets": "3582,3663,6014,6113,6198,6585,6680,6769,6851,6929,7012,7163,7238,7313,7387,7565,7633,7753"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\322e005fb7384ca41aaea870471f9aa7\\transformed\\play-services-basement-18.5.0\\res\\values-is\\values.xml",
                    "from": {
                        "startLines": "4",
                        "startColumns": "0",
                        "startOffsets": "195",
                        "endColumns": "124",
                        "endOffsets": "319"
                    },
                    "to": {
                        "startLines": "46",
                        "startColumns": "4",
                        "startOffsets": "4642",
                        "endColumns": "128",
                        "endOffsets": "4766"
                    }
                },
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\168558c8b26b86308b25cf5137046d4d\\transformed\\core-1.13.1\\res\\values-is\\values-is.xml",
                    "from": {
                        "startLines": "2,3,4,5,6,7,8,9",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "55,150,257,354,454,557,661,772",
                        "endColumns": "94,106,96,99,102,103,110,100",
                        "endOffsets": "145,252,349,449,552,656,767,868"
                    },
                    "to": {
                        "startLines": "29,30,31,32,33,34,35,74",
                        "startColumns": "4,4,4,4,4,4,4,4",
                        "startOffsets": "2779,2874,2981,3078,3178,3281,3385,7392",
                        "endColumns": "94,106,96,99,102,103,110,100",
                        "endOffsets": "2869,2976,3073,3173,3276,3380,3491,7488"
                    }
                }
            ]
        }
    ]
}
```