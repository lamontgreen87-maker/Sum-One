Source: sidequest-build\.gradle\caches\8.14.3\transforms\e2ac816cc322e0622c8e36eeb217f096\transformed\fbjni-0.7.0\prefab\modules\fbjni\libs\android.armeabi-v7a\abi.json

```json
{
  "abi": "armeabi-v7a",
  "api": 21,
  "ndk": 27,
  "stl": "c++_shared",
  "static": false
}
```