Source: mobile\.expo\devices.json

```json
{
  "devices": []
}

```