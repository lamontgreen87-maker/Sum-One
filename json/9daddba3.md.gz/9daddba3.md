Source: mobile\android\app\build\intermediates\merged_res_blame_folder\playRelease\mergePlayReleaseResources\out\multi-v2\values-ldltr-v21.json

```json
{
    "logs": [
        {
            "outputFile": "com.anonymous.dungeoncrawler.app-mergePlayReleaseResources-53:/values-ldltr-v21/values-ldltr-v21.xml",
            "map": [
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\5b3abb9f9b4bacf15b4212ab7576afa0\\transformed\\appcompat-1.6.1\\res\\values-ldltr-v21\\values-ldltr-v21.xml",
                    "from": {
                        "startLines": "2",
                        "startColumns": "4",
                        "startOffsets": "55",
                        "endColumns": "112",
                        "endOffsets": "163"
                    }
                }
            ]
        }
    ]
}
```