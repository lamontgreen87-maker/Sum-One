Source: mobile\android\app\build\intermediates\merged_res_blame_folder\playRelease\mergePlayReleaseResources\out\multi-v2\values-v18.json

```json
{
    "logs": [
        {
            "outputFile": "com.anonymous.dungeoncrawler.app-mergePlayReleaseResources-53:/values-v18/values-v18.xml",
            "map": [
                {
                    "source": "C:\\Users\\Lamont\\.gradle\\caches\\8.10.2\\transforms\\5b3abb9f9b4bacf15b4212ab7576afa0\\transformed\\appcompat-1.6.1\\res\\values-v18\\values-v18.xml",
                    "from": {
                        "startLines": "2",
                        "startColumns": "4",
                        "startOffsets": "55",
                        "endColumns": "48",
                        "endOffsets": "99"
                    }
                }
            ]
        }
    ]
}
```